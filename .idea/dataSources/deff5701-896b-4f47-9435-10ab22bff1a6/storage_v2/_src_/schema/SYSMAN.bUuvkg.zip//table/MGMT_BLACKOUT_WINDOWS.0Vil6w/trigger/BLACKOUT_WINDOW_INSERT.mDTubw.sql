create trigger BLACKOUT_WINDOW_INSERT
  before insert or update
  on MGMT_BLACKOUT_WINDOWS
  for each row
  DECLARE
    l_timezone_region MGMT_TARGETS.timezone_region%TYPE;
BEGIN
    SELECT timezone_region INTO l_timezone_region FROM MGMT_TARGETS WHERE
        target_guid=:new.target_guid;

    :new.utc_start_time :=
       MGMT_GLOBAL.to_utc(:new.start_time, l_timezone_region);

    IF :new.end_time IS NOT NULL THEN
        :new.utc_end_time :=
           MGMT_GLOBAL.to_utc(:new.end_time, l_timezone_region);
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        NULL;
END;
/

