create view MGMT_PROVISION_SUITEMEMBER_CNT as
  SELECT
    suite_inst_guid, count(*) member_count
FROM
    mgmt_prov_suite_inst_members
GROUP BY
    suite_inst_guid
WITH READ ONLY
/

