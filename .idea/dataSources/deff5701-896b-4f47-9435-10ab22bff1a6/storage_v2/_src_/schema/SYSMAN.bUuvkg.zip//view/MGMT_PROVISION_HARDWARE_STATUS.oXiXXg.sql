create view MGMT_PROVISION_HARDWARE_STATUS as
  SELECT
    hw.hw_guid, hw.name, hw.description, hw.hostname, hw.new_hostname,
    hw.mac_address1, hw.mac_address2, hw.mac_address3, hw.mac_address4,
    hw.interface_name1, hw.interface_name2, hw.interface_name3, hw.interface_name4,
    hw.serial_number, hw.rf_id, hw.purpose,
    tgt.current_asn_guid, tgt.last_suc_asn_guid,tgt.component_urn,
    tgt.network_urn, tgt.status
FROM
    mgmt_prov_hardware hw, mgmt_prov_tgt_status tgt
WHERE
    hw.hw_guid = tgt.prov_tgt_guid
AND
    tgt.prov_target_type = 'hw'
WITH READ ONLY
/

