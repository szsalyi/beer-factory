create view MGMT_SPACE_PURGE as
  SELECT target_guid, metric_name
  FROM mgmt_space_metrics WITH CHECK OPTION
/

