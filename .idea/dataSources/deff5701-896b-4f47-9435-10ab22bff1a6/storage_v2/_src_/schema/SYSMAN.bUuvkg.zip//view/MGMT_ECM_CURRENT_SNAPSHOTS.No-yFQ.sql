create view MGMT$ECM_CURRENT_SNAPSHOTS as
  select SNAPSHOT_GUID as ECM_SNAPSHOT_ID,
  SNAPSHOT_TYPE, s.START_TIMESTAMP, s.TARGET_GUID, s.TARGET_NAME, s.TARGET_TYPE,
  s.DISPLAY_TARGET_NAME, s.DISPLAY_TARGET_TYPE, s.ELAPSED_TIME, s.DESCRIPTION,
  s.MESSAGE, STATUS, s.SAVED_TIMESTAMP, t.HOST_NAME
from mgmt_ecm_gen_snapshot s, mgmt_targets t where
s.target_guid = t.target_guid and s.is_current = 'Y'
/

