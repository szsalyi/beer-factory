create view MGMT$SOFTWARE_PATCHES_IN_HOMES as
  select
  s.target_name as host_name,
  h.container_name as home_name,
  h.container_location as home_location,
  p.id as Patch_id,
  ecm_util.concat_col('BUG_NUMBER', 'MGMT_INV_PATCH_FIXED_BUG', 'PATCH_GUID = ''' || p.patch_guid || '''', ',') as bugs_fixed,
  s.snapshot_guid
from
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_inv_container h,
  mgmt_inv_patch p
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = h.snapshot_guid and
  h.container_guid = p.container_guid
/

