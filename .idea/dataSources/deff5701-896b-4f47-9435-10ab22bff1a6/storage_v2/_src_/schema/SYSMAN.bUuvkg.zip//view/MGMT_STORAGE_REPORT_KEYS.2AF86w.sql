create view MGMT$STORAGE_REPORT_KEYS as
  SELECT
  b.target_name,
  b.target_type,
  a.key_value,
  a.parent_key_value
FROM mgmt_storage_report_keys a,
     mgmt$ecm_current_snapshots b
WHERE  a.ecm_snapshot_id = b.ecm_snapshot_id
AND    b.snapshot_type = 'host_storage'
/

