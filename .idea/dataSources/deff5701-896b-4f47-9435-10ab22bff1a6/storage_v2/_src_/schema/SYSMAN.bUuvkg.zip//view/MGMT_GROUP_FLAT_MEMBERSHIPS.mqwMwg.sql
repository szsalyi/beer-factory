create view MGMT$GROUP_FLAT_MEMBERSHIPS as
  SELECT ct.target_name composite_target_name,
         ct.target_type composite_target_type,
         ct.target_guid composite_target_guid,
         mt.target_name member_target_name,
         mt.target_type member_target_type,
         mt.target_guid member_target_guid
   FROM  mgmt_flat_target_assoc a,
         mgmt_targets ct,
         mgmt_targets mt
  WHERE  is_membership = 1
    AND  ct.target_guid = a.source_target_guid
    AND  mt.target_guid = a.assoc_target_guid
  WITH READ ONLY
/

