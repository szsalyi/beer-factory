create view EM$STRING_METRIC_HISTORY as
  SELECT
        t.target_name, t.target_type, t.target_guid, m.metric_name,
        m.metric_column, m.key_column, r.key_value, collection_timestamp,
        TO_CHAR (collection_timestamp), string_value,
        description, unit,
        DECODE (warning_operator, 0, 'GT', 1, 'EQ', 2, 'LT', 3, 'LE', 4, 'GE',
                                  5, 'CONTAINS', 6, 'NE'),
        warning_threshold,
        DECODE (critical_operator, 0, 'GT', 1, 'EQ', 2, 'LT', 3, 'LE', 4, 'GE',
                                   5, 'CONTAINS', 6, 'NE'),
        critical_threshold
      FROM
         MGMT_TARGETS t, MGMT_METRICS m,
         MGMT_STRING_METRIC_HISTORY r, MGMT_METRIC_THRESHOLDS th
        WHERE r.metric_guid=m.metric_guid
          AND r.target_guid=t.target_guid
          AND t.target_guid = th.target_guid
          AND m.metric_guid = th.metric_guid
          AND r.key_value = th.key_value
/

