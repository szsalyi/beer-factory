create view EM$RT_REGION_DETAILS_7DAY as
  SELECT
        m.SOURCE_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        m.ASSOC_TARGET_GUID,
        d.METRIC_NAME, R.REGION_NAME,
        d.ROLLUP_TIMESTAMP,
        sum(response_time_average*hits)/sum(hits),
        min(RESPONSE_TIME_MINIMUM), max(RESPONSE_TIME_MAXIMUM),
        sum(RESPONSE_TIME_SDEV*hits)/sum(hits), sum(HITS)
  FROM
        MGMT_RT_DOMAIN_1HOUR d,
        mgmt_rt_regions r,
        MGMT_TARGET_ASSOCS m,
        MGMT_TARGETS ct,
        MGMT_TARGET_ASSOC_DEFS def
  WHERE
        r.target_guid = m.source_target_guid
        and d.target_guid = m.assoc_target_guid
        AND def.assoc_guid = m.assoc_guid
        AND def.assoc_def_name = 'supports_eum_on'
        AND def.scope_target_type = ' '
        AND ct.target_guid  = m.source_target_guid
        and r.region_guid IN (select mp.region_guid /*+ INDEX(mgmt_rt_region_entries IDX_REGION_MIN_IP) */ FROM mgmt_rt_region_entries e, mgmt_rt_region_mapping mp WHERE e.id = mp.id AND ((e.min_ip >= 0 AND d.visitor_subnet_num between e.min_ip AND e.max_ip) OR (e.min_ip < 0 AND UPPER(substr('.'||d.visitor_domain, -LENGTH(e.domain)-1)) = UPPER('.'||e.domain))))
  GROUP BY m.SOURCE_TARGET_GUID, m.ASSOC_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        d.METRIC_NAME, r.REGION_NAME, d.ROLLUP_TIMESTAMP
/

