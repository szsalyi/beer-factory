create view MGMT$AVAILABILITY_CURRENT as
  SELECT
            t.target_name, t.target_type, t.target_guid,
			v.start_collection_timestamp,
            DECODE (v.current_status, 0, 'Target Down', 1, 'Target Up',
                                      2, 'Metric Error',
                                      3, 'Agent Down', 4, 'Unreachable',
                                      5, 'Blackout', 6, 'Pending/Unknown'),
			tt.type_display_name
          FROM
            mgmt_targets t,
			mgmt_target_types tt,
            mgmt_current_availability v
          WHERE t.target_guid = v.target_guid
		    AND tt.target_type = t.target_type
    WITH READ ONLY
/

