create trigger COLLECTION_DISABLE_TRIGGER
  before insert or update
  on MGMT_COLLECTIONS
  for each row
  when (new.is_enabled = 0)
  DECLARE
  l_tbl_metric_guid MGMT_METRICS.metric_guid%TYPE;
BEGIN
  IF ( (:new.object_type =  MGMT_GLOBAL.G_OBJECT_TYPE_TARGET) AND
       (INSERTING OR (UPDATING AND :old.is_enabled = 1) ) )
  THEN
    EM_COLL_UTIL.run_disable_steps(:new.object_guid,:new.coll_name) ;
  END IF;
END collection_disable_trigger ;
/

