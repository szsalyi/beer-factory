create view MGMT$JOB_NOTIFICATION_LOG as
  SELECT
	     j.job_name, j.job_owner,
             decode(sc.newstate, 1, 'SCHEDULED', 2, 'EXECUTING',
				 3, 'ABORTED', 4, 'FAILED',
				 5, 'COMPLETED', 6, 'SUSPENDED',
				 7, 'AGENT DOWN', 8, 'STOPPED',
				 9, 'SUSPENDED/LOCK', 10, 'SUSPENDED/EVENT',
				 11, 'SUSPENDED/BLACKOUT', 12, 'STOP PENDING',
				 13, 'SUSPEND PENDING', 14, 'INACTIVE',
				 15, 'QUEUED', 16, 'FAILED',
				 17, 'WAITING', 18, 'SKIPPED',
				 newstate),
             sc.occurred, n.message, n.timestamp
           FROM mgmt_notification_log n,
	        mgmt_job_state_changes sc,
		mgmt_job j
           WHERE n.source_obj_type = 3
             AND sc.state_change_guid = n.source_obj_guid
             AND j.job_id = sc.job_id
	WITH READ ONLY
/

