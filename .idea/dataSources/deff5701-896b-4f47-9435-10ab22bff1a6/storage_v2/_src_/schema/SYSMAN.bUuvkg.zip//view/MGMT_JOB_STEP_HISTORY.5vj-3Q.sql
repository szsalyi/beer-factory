create view MGMT$JOB_STEP_HISTORY as
  SELECT
        j.job_name, j.job_owner, j.job_id,
        e.execution_id, h.step_name,
        h.start_time, h.end_time,
        DECODE(h.step_status,
                1, 'Scheduled',
                2, 'Running',
                3, 'Failed Initialization',
                4, 'Failed',
                5, 'Succeeded',
                6, 'Suspended By User',
                7, 'Suspended: Agent Unreacheable',
                8, 'Stopped',
                9, 'Suspended on Lock',
               10, 'Suspended on Event',
               11, 'Stop Pending',
               13, 'Suspend Pending',
               14, 'Inactive',
               15, 'Queued',
               16, 'Failed Retried',
               18, 'Skipped', status),
        t.target_name, t.target_type, t.target_guid, o.output
      FROM
        MGMT_JOB j,
        MGMT_JOB_EXEC_SUMMARY e,
        MGMT_JOB_HISTORY h,
        MGMT_JOB_OUTPUT o,
        MGMT_JOB_STEP_TARGETS st,
        MGMT_TARGETS t
      WHERE
        j.job_id=e.job_id AND
        j.is_corrective_action=0 AND
        e.execution_id=h.execution_id AND
        h.step_id=st.step_id (+) AND
        h.step_type=1 AND
        st.target_guid=t.target_guid (+) AND
        h.output_id=o.output_id (+)
      WITH READ ONLY
/

