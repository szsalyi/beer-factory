create view EM$RT_CURRENT_URL_AVG_1HOUR as
  SELECT COMPOSITE_TARGET_GUID,
        COMPOSITE_TARGET_NAME, COMPOSITE_TARGET_TYPE,
        METRIC_NAME, URL_FILENAME,
        sum(RESPONSE_TIME_AVERAGE*HITS)/sum(HITS) as RESPONSE_TIME_CURRENT_AVG
  FROM
        (SELECT m.source_target_guid composite_target_guid,
            ct.target_name composite_target_name, ct.target_type composite_target_type,
            d.metric_name, d.url_filename, d.response_time_average,
            d.rollup_timestamp, max(d.rollup_timestamp)
            OVER (PARTITION by m.source_target_guid,
              metric_name, url_filename) as ts_max, d.hits
            FROM MGMT_RT_URL_1HOUR d,
              MGMT_TARGET_ASSOCS m,
              MGMT_TARGETS ct,
              MGMT_TARGET_ASSOC_DEFS def
            WHERE d.target_guid = m.assoc_target_guid
              AND def.assoc_guid = m.assoc_guid
              AND def.assoc_def_name = 'supports_eum_on'
              AND def.scope_target_type = ' '
              AND ct.target_guid  = m.source_target_guid
        ) WHERE rollup_timestamp = ts_max
         group by  COMPOSITE_TARGET_GUID,
           COMPOSITE_TARGET_NAME, COMPOSITE_TARGET_TYPE,
           METRIC_NAME, URL_FILENAME
/

