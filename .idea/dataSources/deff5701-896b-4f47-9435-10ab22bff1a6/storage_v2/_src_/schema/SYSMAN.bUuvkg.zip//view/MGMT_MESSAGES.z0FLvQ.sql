create view MGMT$MESSAGES as
  SELECT message_id, subsystem, language_code, country_code, message
    FROM mgmt_messages
 WITH READ ONLY
/

