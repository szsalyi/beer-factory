create trigger EM_ADAPTIVE_THRESHOLDS_INS
  instead of insert
  on EM_ADAPTIVE_THRESHOLDS
  for each row
  declare
   l_metric_guid  mgmt_metrics.metric_guid%TYPE;
begin
   -----------------------------------------------------------
   -- get metric guid (10gR2 does not know this)
   -----------------------------------------------------------
   begin
   l_metric_guid := mgmt_bsln_internal.metric_guid_by_name
                      (target_type_in => :new.target_type
                      ,metric_name_in => :new.metric_name
                      ,metric_column_in => :new.metric_column
                     );
   -- Adding exception block - Bug#6082301
   exception
      -- ignore case when metric column not found
      when NO_DATA_FOUND then null;
   end;
   -----------------------------------------------------------
   -- update policy config for this metric across collections
   -----------------------------------------------------------
   if l_metric_guid is not null
   then
      mgmt_bsln_internal.set_metric_bsln_flag
                           (target_guid_in => :new.target_guid
                           ,metric_guid_in => l_metric_guid
                           ,key_value_in   => :new.key_value
                           ,flag_value_in  => :new.has_active_baseline
                           );
   end if;
end;
/

