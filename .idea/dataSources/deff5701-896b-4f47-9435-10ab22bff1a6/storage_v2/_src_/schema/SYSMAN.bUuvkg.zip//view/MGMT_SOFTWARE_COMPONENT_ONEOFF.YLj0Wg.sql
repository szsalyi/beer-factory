create view MGMT$SOFTWARE_COMPONENT_ONEOFF as
  SELECT
  s.target_name as HOST_NAME,
  h.container_name as HOME_NAME,
  h.container_location as HOME_LOCATION,
  c.name as COMPONENT_NAME,
  c.external_name as COMPONENT_EXTERNAL_NAME,
  decode(vpatch.version, NULL, c.version, vpatch.version) as COMPONENT_VERSION,
  c.version as COMPONENT_BASE_VERSION,
  p.ID as PATCH_ID,
  s.snapshot_guid
FROM
  mgmt_ecm_snapshot s,
  mgmt_inv_container h,
  mgmt_inv_component c,
  mgmt_inv_component_patch cp,
  mgmt_inv_patch p,
  mgmt_inv_versioned_patch vpatch,
  mgmt_targets t
WHERE s.is_current = 'Y'
      AND s.snapshot_type = 'host_configuration'
      AND s.snapshot_guid = h.snapshot_guid
      AND h.container_guid = c.container_guid
      AND p.container_guid = h.container_guid
      AND cp.component_guid = c.component_guid
      AND cp.patch_guid = p.patch_guid
      AND c.component_guid = vpatch.component_guid(+)
      AND t.target_name = s.target_name
      AND t.target_type = 'host'
/

