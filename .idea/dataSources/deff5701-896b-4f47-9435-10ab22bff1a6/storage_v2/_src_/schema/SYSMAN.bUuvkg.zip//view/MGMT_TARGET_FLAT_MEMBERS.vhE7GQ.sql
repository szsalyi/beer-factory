create view MGMT$TARGET_FLAT_MEMBERS as
  SELECT
		     t1.target_name, t1.target_type,
             t1.target_guid, t2.target_name,
             t2.target_type, t2.target_guid
        FROM  mgmt_flat_target_assoc a,
              mgmt_targets t1,
              mgmt_targets t2
        WHERE  is_membership = 1
          AND  t1.target_guid = a.source_target_guid
          AND  t2.target_guid = a.assoc_target_guid
   WITH READ ONLY
/

