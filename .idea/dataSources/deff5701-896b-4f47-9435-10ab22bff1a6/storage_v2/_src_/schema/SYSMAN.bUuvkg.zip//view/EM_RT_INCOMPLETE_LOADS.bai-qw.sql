create view EM$RT_INCOMPLETE_LOADS as
  SELECT
      i.target_guid, page_url, num_incomplete_loads,
      avg_server_time, i.rollup_timestamp
    FROM
      MGMT_RT_INCOMPLETE_LOADS_1HOUR i, MGMT_TARGET_ROLLUP_TIMES r
    WHERE i.target_guid = r.target_guid
      AND r.rollup_table_name = 'MGMT_RT_INCOMPLETE_LOADS_1HOUR'
      AND i.rollup_timestamp <= r.rollup_timestamp
    UNION
    SELECT
      i.target_guid, page_url, num_incomplete_loads,
      avg_server_time, aggregate_hour_timestamp
    FROM
      MGMT_RT_INCOMPLETE_LOADS i, MGMT_TARGET_ROLLUP_TIMES r
    WHERE i.target_guid = r.target_guid
      AND r.rollup_table_name = 'MGMT_RT_INCOMPLETE_LOADS_1HOUR'
      AND TRUNC(i.aggregate_hour_timestamp, 'HH24') > r.rollup_timestamp
/

