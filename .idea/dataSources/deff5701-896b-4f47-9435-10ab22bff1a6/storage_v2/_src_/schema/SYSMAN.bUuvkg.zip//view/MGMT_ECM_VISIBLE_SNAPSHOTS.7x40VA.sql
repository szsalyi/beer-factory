create view MGMT$ECM_VISIBLE_SNAPSHOTS as
  select SNAPSHOT_GUID as ECM_SNAPSHOT_ID,
  SNAPSHOT_TYPE, START_TIMESTAMP, TARGET_GUID, TARGET_NAME, TARGET_TYPE,
  DISPLAY_TARGET_NAME, DISPLAY_TARGET_TYPE, ELAPSED_TIME, DESCRIPTION,
  IS_CURRENT, MESSAGE, STATUS, CREATOR, SAVED_TIMESTAMP
from mgmt_ecm_gen_snapshot s where
(exists (select * from mgmt_targets t where s.target_guid = t.target_guid) or
(mgmt_user.has_priv(mgmt_user.get_current_em_user(), 'SUPER_USER') = 1) or
(s.creator = mgmt_user.get_current_em_user()))
AND
(is_current = 'Y' or is_current = 'N')
/

