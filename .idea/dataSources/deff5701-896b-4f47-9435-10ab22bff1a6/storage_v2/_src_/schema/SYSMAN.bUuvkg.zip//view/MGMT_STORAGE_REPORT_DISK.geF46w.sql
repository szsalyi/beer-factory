create view MGMT$STORAGE_REPORT_DISK as
  SELECT
  b.target_name,
  b.target_type,
  entity_type,
  NVL(a3,name),
  a4,
  sizeb,
  usedb,
  freeb,
  a1,
  a2
FROM mgmt_storage_report_data a,
     mgmt$ecm_current_snapshots b
WHERE storage_layer = 'OS_DISK'
AND   a.ecm_snapshot_id = b.ecm_snapshot_id
AND   b.snapshot_type = 'host_storage'
/

