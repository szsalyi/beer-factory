create view MGMT$CSM_REGION as
  SELECT
  tg.target_name, tg.target_type,
  rg.region_name, rg.description, re.domain,
  DECODE(re.min_ip,
    -1, 'DOMAIN',
    'SUBNET')
FROM
  MGMT_TARGETS tg,
  MGMT_RT_REGIONS rg,
  MGMT_RT_REGION_MAPPING rm,
  MGMT_RT_REGION_ENTRIES re
WHERE
  tg.target_guid = rg.target_guid
  AND rg.region_guid = rm.region_guid
  AND rm.id = re.id
WITH READ ONLY
/

