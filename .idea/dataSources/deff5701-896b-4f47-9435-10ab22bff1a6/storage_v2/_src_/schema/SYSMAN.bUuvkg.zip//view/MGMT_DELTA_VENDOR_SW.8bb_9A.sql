create view MGMT$DELTA_VENDOR_SW as
  select host_name, refresh_time, operation, product, vendor,
    version, location, description
    from
(select
    s.new_left_target_name as host_name,
    e.delta_time as refresh_time,
    e.operation as operation,
    p.value as product,
    v.value as vendor,
    r.value as version,
    l.value as location,
    MGMT_DELTA.GET_DELTA_VALUE_DISPLAY_STRING( e.delta_entry_guid, e.operation ) as description
  from
    mgmt_delta_entry e,
    mgmt_delta_ids i,
    mgmt_delta_id_values p,
    mgmt_delta_id_values v,
    mgmt_delta_id_values r,
    mgmt_delta_id_values l,
    mgmt_delta_snap s,
    mgmt_targets t
  where
    i.collection_type = 'ECM$HIST_OS_REGISTERED_SW' and
    i.row_guid = e.row_guid and
    p.delta_ids_guid = i.row_guid and
    p.name = 'NAME' and
    v.delta_ids_guid = i.row_guid and
    v.name = 'VENDOR_NAME' and
    l.delta_ids_guid = i.row_guid and
    l.name = 'INSTALLED_LOCATION' and
    r.delta_ids_guid = i.row_guid and
    r.name = 'VERSION' and
    t.target_name = s.new_left_target_name and
    t.target_type = 'host' and
    e.delta_guid = s.delta_guid and
    s.target_type = 'host' and
    s.snapshot_type = 'host_configuration')
UNION ALL
(select
    s.new_left_target_name as host_name,
    e.delta_time as refresh_time,
    'UPDATE' as operation,
    p.value as product,
    v.value as vendor,
    r.value as version,
    l.value as location,
    case e.operation
      when 'INSERT' THEN 'Added ' || t.value || ' ' || n.value || ' ' || c.value
      when 'DELETE' THEN 'Removed ' || t.value || ' ' || n.value || ' ' || c.value
      else e.operation || t.value || ' ' || n.value || ' ' || c.value || ': ' ||
      MGMT_DELTA.GET_DELTA_VALUE_DISPLAY_STRING( e.delta_entry_guid, e.operation )
    end as description
  from
    mgmt_delta_entry e,
    mgmt_delta_ids i,
    mgmt_delta_id_values p,
    mgmt_delta_id_values v,
    mgmt_delta_id_values r,
    mgmt_delta_id_values l,
    mgmt_delta_id_values n,
    mgmt_delta_id_values t,
    mgmt_delta_id_values c,
    mgmt_delta_snap s,
    mgmt_targets t
  where
    i.collection_type = 'MGMT_HC_VENDOR_SW_COMPONENTS' and
    i.row_guid = e.row_guid and
    p.delta_ids_guid = i.row_guid and
    p.name = 'SW_NAME' and
    v.delta_ids_guid = i.row_guid and
    v.name = 'VENDOR_NAME' and
    l.delta_ids_guid = i.row_guid and
    l.name = 'SW_INSTALLED_LOCATION' and
    r.delta_ids_guid = i.row_guid and
    r.name = 'SW_VERSION' and
    n.delta_ids_guid = i.row_guid and
    n.name = 'COMPONENT_NAME' and
    t.delta_ids_guid = i.row_guid and
    t.name = 'TYPE' and
    c.delta_ids_guid = i.row_guid and
    c.name = 'VERSION' and
    t.target_name = s.new_left_target_name and
    t.target_type = 'host' and
    e.delta_guid = s.delta_guid and
    s.target_type = 'host' and
    s.snapshot_type = 'host_configuration')
/

