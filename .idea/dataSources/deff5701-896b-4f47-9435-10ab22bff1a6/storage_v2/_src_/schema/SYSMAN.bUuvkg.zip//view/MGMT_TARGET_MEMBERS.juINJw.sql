create view MGMT$TARGET_MEMBERS as
  SELECT
             t1.target_name, t1.target_type, t1.target_guid,
             t2.target_name, t2.target_type, t2.target_guid
           FROM
             mgmt_target_assocs a,
             mgmt_targets t1,
             mgmt_targets t2
           WHERE a.assoc_guid = hextoraw('CC038C4568AE2A331C948E492A0401DF')
             AND a.source_target_guid = t1.target_guid
             AND a.assoc_target_guid  = t2.target_guid
   WITH READ ONLY
/

