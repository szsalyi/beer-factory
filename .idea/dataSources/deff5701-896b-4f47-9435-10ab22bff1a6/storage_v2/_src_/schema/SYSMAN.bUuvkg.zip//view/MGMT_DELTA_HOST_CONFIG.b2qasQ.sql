create view MGMT$DELTA_HOST_CONFIG as
  select
    s.new_left_target_name as host,
    MGMT_DELTA.GET_DELTA_KEY_DISPLAY_STRING( i.row_guid ) as key,
    e.delta_time as refresh_time,
    e.operation as operation,
    i.collection_type as collection_type,
    tab.ui_name as coll_type_text,
    MGMT_DELTA.GET_DELTA_VALUE_DISPLAY_STRING( e.delta_entry_guid, e.operation ) as details
  from
    mgmt_delta_entry e,
    mgmt_delta_snap s,
    mgmt_targets t,
    mgmt_delta_ids i,
    mgmt_ecm_snapshot_md_tables tab
  where
    i.row_guid = e.row_guid and
    i.collection_type = tab.name and
    t.target_name = s.new_left_target_name and
    t.target_type = 'host' and
    e.delta_guid = s.delta_guid and
    s.target_type = 'host' and
    s.snapshot_type = 'host_configuration'
/

