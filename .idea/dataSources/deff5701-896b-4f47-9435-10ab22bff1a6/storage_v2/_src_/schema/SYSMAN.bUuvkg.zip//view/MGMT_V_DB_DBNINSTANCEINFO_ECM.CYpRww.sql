create view MGMT_V_DB_DBNINSTANCEINFO_ECM as
  SELECT	ecm_snapshot_id
FROM    mgmt_db_dbninstanceinfo_ecm
/

