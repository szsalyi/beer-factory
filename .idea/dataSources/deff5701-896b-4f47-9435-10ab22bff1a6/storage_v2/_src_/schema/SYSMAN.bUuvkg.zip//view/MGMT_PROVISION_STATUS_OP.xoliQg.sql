create view MGMT_PROVISION_STATUS_OP as
  SELECT
    tgt.prov_tgt_guid, hist.assignment_guid,
    op.op_guid, tgt.prov_target_type,
    op.last_modified_time, op.op_type, op.job_id,
    op.status_msg, op.fraction_complete, op.creation_time
FROM
    mgmt_prov_tgt_status tgt, mgmt_prov_history hist, mgmt_prov_operation op
WHERE
    tgt.prov_tgt_guid = hist.prov_tgt_guid
AND
    (tgt.current_asn_guid IS NULL OR
     tgt.current_asn_guid = hist.assignment_guid)
AND
    hist.op_guid = op.op_guid
WITH READ ONLY
/

