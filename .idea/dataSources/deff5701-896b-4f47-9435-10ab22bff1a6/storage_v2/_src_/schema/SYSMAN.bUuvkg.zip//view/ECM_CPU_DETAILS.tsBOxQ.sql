create view ECM$CPU_DETAILS as
  select
  snapshot_guid as ecm_snapshot_id,
  vendor_name,
  freq_in_mhz,
  ecache_in_mb,
  impl,
  revision,
  mask,
  count(*) as count
from
  MGMT_HC_CPU_DETAILS
group by snapshot_guid, vendor_name, freq_in_mhz,ecache_in_mb,impl, revision,mask
/

