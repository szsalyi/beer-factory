create view EM$RT_METRICS_DETAILS_7DAY as
  SELECT
        d.target_guid,
        t.target_name, t.target_type,
        METRIC_NAME, METRIC_COLUMN,
        column_label,
        ROLLUP_TIMESTAMP,
        VALUE_AVERAGE, VALUE_MINIMUM,
        VALUE_MAXIMUM, VALUE_SDEV
  FROM
        MGMT_METRICS_1HOUR d, MGMT_METRICS mt, MGMT_TARGETS t
  WHERE
        ROLLUP_TIMESTAMP >= (SYSDATE - 7)
        AND d.metric_guid = mt.metric_guid
        AND d.target_guid = t.target_guid
        AND mt.metric_name = 'Response'
        AND mt.metric_column != 'Status'
        AND mt.metric_column is not null
        AND mt.metric_type = 0
        AND t.target_type = mt.target_type
        AND t.type_meta_ver = mt.type_meta_ver
        AND (t.category_prop_1 = mt.category_prop_1 OR mt.category_prop_1 = ' ')
        AND (t.category_prop_2 = mt.category_prop_2 OR mt.category_prop_2 = ' ')
        AND (t.category_prop_3 = mt.category_prop_3 OR mt.category_prop_3 = ' ')
        AND (t.category_prop_4 = mt.category_prop_4 OR mt.category_prop_4 = ' ')
        AND (t.category_prop_5 = mt.category_prop_5 OR mt.category_prop_5 = ' ')
/

