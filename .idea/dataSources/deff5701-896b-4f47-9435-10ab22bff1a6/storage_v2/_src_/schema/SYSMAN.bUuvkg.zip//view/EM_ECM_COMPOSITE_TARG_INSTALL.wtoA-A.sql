create view EM$ECM_COMPOSITE_TARG_INSTALL as
  select
  composite_target_name,
  composite_target_type,
  inst.target_type,
  external_name,
  version,
  count( distinct container_guid ) as num_installs,
  count(distinct target_guid ) as num_instances,
  case sum(num_patched) when 0 then 'No' else 'Yes' end as patched
from
  ( select
      map.target_type,
      component.external_name,
      case when ps_patch.version is null then component.version else ps_patch.version end as version,
      host.target_name as host_name,
      home.container_location,
      case  when exists ( select * from mgmt_inv_patch p where p.container_guid = home.container_guid )then 1 else 0 end as num_patched,
      home.container_guid
    from
      mgmt_targets host,
      mgmt_ecm_snapshot snapshot,
      mgmt_inv_container home,
      mgmt_inv_component component,
      mgmt_inv_versioned_patch ps_patch,
      mgmt_target_type_component_map map
    where host.target_type = 'host'
      and host.target_name = snapshot.target_name
      and host.target_type = snapshot.target_type
      and snapshot.snapshot_type = 'host_configuration'
      and snapshot.is_current = 'Y'
      and home.snapshot_guid = snapshot.snapshot_guid
      and component.container_guid = home.container_guid
      and component.component_guid = ps_patch.component_guid(+)
      and map.component_name = component.name
  ) inst,
  ( select
      ct.target_name composite_target_name,
      ct.target_type composite_target_type,
      host.target_name as host_target_name,
      target.target_name as target_name,
      target.target_type as target_type,
      property.property_value as home_location,
      target.target_guid
    from
      mgmt_target_assocs composite,
      mgmt_targets ct,
      mgmt_target_assoc_defs def,
      mgmt_targets host,
      mgmt_targets target,
      mgmt_target_properties property
    where composite.assoc_target_guid = target.target_guid
      and host.target_type = 'host'
      and host.target_name     = target.host_name
      and property.target_guid = target.target_guid
      and property.property_name = 'OracleHome'
      and composite.assoc_guid = def.assoc_guid
      and def.assoc_def_name = 'contains'
      and def.scope_target_type = ' '
      and ct.target_guid = composite.source_target_guid
  ) targs
where inst.host_name = targs.host_target_name(+)
  and inst.container_location = targs.home_location(+)
  and inst.target_type = targs.target_type(+)
group by composite_target_name, composite_target_type, inst.target_type, external_name, version
WITH READ ONLY
/

