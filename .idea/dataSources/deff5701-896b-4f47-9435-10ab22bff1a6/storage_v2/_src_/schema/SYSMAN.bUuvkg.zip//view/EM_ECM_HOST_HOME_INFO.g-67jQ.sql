create view EM$ECM_HOST_HOME_INFO as
  SELECT
  t.target_name as host_name,
  ecm_util.concat_col( 'home',
                      '(select s.target_name as target, s.target_type as target_type,
                        c.container_location || ''('' || c.container_name || '')'' as home
                        from mgmt_ecm_snapshot s, mgmt_inv_container c
                        where s.is_current = ''Y'' and s.snapshot_type = ''host_configuration''
                          and s.snapshot_guid = c.snapshot_guid)',
                           '''' || t.target_type || ''' = target_type and target = ''' ||
                           t.target_name || '''',
                           ', ' ) as home_info,
  os.name as os_name,
  os.base_version os_base_version,
  os.update_level os_update_level,
  os.address_length_in_bits os_address_length_in_bits
FROM
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_os_summary os
WHERE t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = os.snapshot_guid
  WITH READ ONLY
/

