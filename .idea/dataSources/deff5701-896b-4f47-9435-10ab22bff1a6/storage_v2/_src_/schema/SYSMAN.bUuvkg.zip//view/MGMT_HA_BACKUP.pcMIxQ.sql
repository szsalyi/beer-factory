create view MGMT$HA_BACKUP as
  select
  d.host_name as host,
  d.target_name as database_name,
  d.target_type,
  d.display_name,
  b.target_guid,
  b.session_key,
  b.session_recid,
  b.session_stamp,
  b.command_id,
  b.status,
  b.start_time,
  b.end_time,
  b.time_taken_display,
  b.input_type,
  b.output_device_type,
  b.input_bytes_display,
  b.output_bytes_display,
  b.output_bytes_per_sec_display
from
  mgmt_targets d,
  mgmt_ha_backup b
where
  (d.target_type = 'oracle_database' or d.target_type = 'rac_database') and
  d.target_guid = b.target_guid
/

