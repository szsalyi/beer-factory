create view EMDW$TRACE_DATA as
  select  etd.Context_type_Id,
        etc.Context_type,
        etd.log_level,
        decode(etd.log_Level,1,'ERROR',
                            2,'WARNING',
                            3,'INFO',
                            4,'DEBUG','UNKNOWN') log_Level_Desc,
       etd.log_timestamp,
       etd.log_message,
       etd.module,
       etd.oms_host,
       etd.context_identifier
from emdw_trace_config etc,
     emdw_trace_data   etd
where etc.context_type_id = etd.context_type_id
/

