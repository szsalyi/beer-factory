create view MGMT$DELTA_HARDWARE as
  select d.host_name, d.refresh_time, d.operation,
    d.description
from
((select
    s.new_left_target_name as host_name,
    e.delta_time as refresh_time,
    case when e.operation = 'UPDATE' and d.old_value < d.value THEN 'INSERT'
         when e.operation = 'UPDATE' and d.value < d.old_value THEN 'DELETE'
         else e.operation end as operation,
    'CPU: ' || mhz.value || ' mhz ' || impl.value  as description
  from
    mgmt_delta_entry e,
    mgmt_delta_ids i,
    mgmt_delta_entry_values d,
    mgmt_delta_id_values mhz,
    mgmt_delta_id_values impl,
    mgmt_delta_snap s,
    mgmt_targets t
  where
    i.collection_type = 'ECM$HIST_CPU_DETAILS' and
    i.row_guid = e.row_guid and
    e.delta_entry_guid = d.delta_entry_guid(+) and
    mhz.delta_ids_guid = i.row_guid and
    mhz.name = 'FREQ_IN_MHZ' and
    impl.delta_ids_guid = i.row_guid and
    impl.name = 'IMPL' and
    t.target_name = s.new_left_target_name and
    t.target_type = 'host' and
    e.delta_guid = s.delta_guid and
    s.target_type = 'host' and
    s.snapshot_type = 'host_configuration')
UNION ALL
(select
    s.new_left_target_name as host_name,
    e.delta_time as delta_time,
    case when e.operation = 'UPDATE' and d.old_value < d.value THEN 'INSERT'
         when e.operation = 'UPDATE' and d.value < d.old_value THEN 'DELETE'
         else e.operation end as operation,
    'IOCARD: ' || mhz.value || ' mhz ' || name.value as description
  from
    mgmt_delta_entry e,
    mgmt_delta_ids i,
    mgmt_delta_entry_values d,
    mgmt_delta_id_values mhz,
    mgmt_delta_id_values name,
    mgmt_delta_snap s,
    mgmt_targets t
  where
    i.collection_type = 'ECM$HIST_IOCARD_DETAILS' and
    i.row_guid = e.row_guid and
    e.delta_entry_guid = d.delta_entry_guid(+) and
    mhz.delta_ids_guid = i.row_guid and
    mhz.name = 'FREQ_IN_MHZ' and
    name.delta_ids_guid = i.row_guid and
    name.name = 'NAME' and
    t.target_name = s.new_left_target_name and
    t.target_type = 'host' and
    e.delta_guid = s.delta_guid and
    s.target_type = 'host' and
    s.snapshot_type = 'host_configuration')
UNION ALL
(select
    s.new_left_target_name as host_name,
    e.delta_time as delta_time,
    e.operation as operation,
    MGMT_DELTA.GET_DELTA_VALUE_DISPLAY_STRING( e.delta_entry_guid, e.operation ) as description
  from
    mgmt_delta_entry e,
    mgmt_delta_ids i,
    mgmt_delta_snap s,
    mgmt_targets t
  where
    (i.collection_type = 'ECM$HIST_HARDWARE') and
    i.row_guid = e.row_guid and
    t.target_name = s.new_left_target_name and
    t.target_type = 'host' and
    e.delta_guid = s.delta_guid and
    s.target_type = 'host' and
    s.snapshot_type = 'host_configuration')) d
/

