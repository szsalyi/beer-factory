create trigger INSERT_FLAT_TARGETS
  after insert
  on MGMT_BLACKOUT_TARGET_DETAILS
  for each row
  DECLARE
    l_created_thru MGMT_BLACKOUTS.created_thru%TYPE;
    l_target_type MGMT_TARGETS.target_type%TYPE;
BEGIN
    -- For CLI blackouts, add entries to the flat targets table
    SELECT created_thru INTO l_created_thru
    FROM   MGMT_BLACKOUTS
    WHERE  blackout_guid=:new.blackout_guid;

    IF l_created_thru IS NOT NULL THEN
        -- This is an agent-side blackout
        INSERT INTO MGMT_BLACKOUT_FLAT_TARGETS(blackout_guid, target_guid,
            host_blackout, job_status, blackout_status, last_updated_time)
        VALUES
            (:new.blackout_guid, :new.target_guid, 0,
             MGMT_BLACKOUT_ENGINE.BLK_JSTATE_START_PROCESSING,
             MGMT_BLACKOUT_ENGINE.NOT_IN_BLACKOUT, SYSDATE);

        --Find the target type to make sure that its of type host
        SELECT target_type INTO l_target_type
        FROM   MGMT_TARGETS
        WHERE  target_guid = :new.target_guid;

        --If include_members is true then insert all the dependent targets to the MGMT_BLACKOUT_FLAT_TARGETS
        IF (:new.include_members = 1 AND l_target_type = MGMT_GLOBAL.G_HOST_TARGET_TYPE) THEN
            --Find all the targets guid for this url and insert in MGMT_BLACKOUT_FLAT_TARGETS
            FOR crec IN
            (
                SELECT a.target_guid
                FROM   MGMT_TARGETS a, MGMT_TARGETS h
                WHERE  h.target_guid = :new.target_guid
                AND    h.emd_url=a.emd_url
                AND    a.target_type != MGMT_GLOBAL.G_HOST_TARGET_TYPE
            )
            LOOP
                INSERT INTO MGMT_BLACKOUT_FLAT_TARGETS
                (
                       blackout_guid,
                       target_guid,
                       host_blackout,
                       job_status,
                       blackout_status,
                       last_updated_time
                 )
                 VALUES
                 (
                       :new.blackout_guid,
                       crec.target_guid,
                       0,
                       MGMT_BLACKOUT_ENGINE.BLK_JSTATE_START_PROCESSING,
                       MGMT_BLACKOUT_ENGINE.NOT_IN_BLACKOUT,
                       SYSDATE
                 );
            END LOOP;
        END IF;
    END IF;
END;
/

