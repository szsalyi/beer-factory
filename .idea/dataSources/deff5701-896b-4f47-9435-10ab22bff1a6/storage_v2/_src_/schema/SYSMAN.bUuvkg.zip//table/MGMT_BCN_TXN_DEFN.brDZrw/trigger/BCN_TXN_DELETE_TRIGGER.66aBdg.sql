create trigger BCN_TXN_DELETE_TRIGGER
  after delete
  on MGMT_BCN_TXN_DEFN
  for each row
  DECLARE
    CURSOR key_cursor(tgt RAW, txn VARCHAR2) IS
    SELECT composite_key
    FROM MGMT_METRICS_COMPOSITE_KEYS
    WHERE target_guid = tgt
        AND key_part1_value = txn
        AND key_part3_value IS NULL;

    v_key key_cursor%ROWTYPE;
    v_more BOOLEAN;
BEGIN
    IF :old.txn_guid IS NOT NULL THEN
        DELETE FROM MGMT_BCN_STEP_DEFN
        WHERE target_guid = :old.target_guid
            AND txn_guid = :old.txn_guid;

        DELETE FROM MGMT_BCN_STEPGROUP_DEFN
        WHERE target_guid = :old.target_guid
            AND txn_guid = :old.txn_guid;

        DELETE FROM MGMT_BCN_TXN_PROPS
        WHERE target_guid = :old.target_guid
            AND txn_guid = :old.txn_guid;

        DELETE FROM MGMT_BCN_BCNTXN_PROPS
        WHERE target_guid = :old.target_guid
            AND txn_guid = :old.txn_guid;

        DELETE FROM MGMT_ADMIN_METRIC_THRESHOLDS
         WHERE target_guid = :old.target_guid
           AND coll_name = :old.txn_guid;

        v_more := TRUE;
        OPEN key_cursor(:old.target_guid, :old.name);
        WHILE v_more LOOP
            FETCH key_cursor INTO v_key;
            v_more := key_cursor%FOUND;
            IF v_more = TRUE THEN
                IF v_key.composite_key IS NOT NULL THEN
                    DELETE FROM MGMT_CURRENT_METRICS
                    WHERE target_guid = :old.target_guid
                        AND key_value = v_key.composite_key;

                    DELETE FROM MGMT_METRIC_THRESHOLDS
                    WHERE target_guid = :old.target_guid
                        AND key_value = v_key.composite_key;

                END IF;
            END IF;
        END LOOP;
        CLOSE key_cursor;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        IF key_cursor%ISOPEN THEN
            CLOSE key_cursor;
        END IF;
    RAISE;
END;
/

