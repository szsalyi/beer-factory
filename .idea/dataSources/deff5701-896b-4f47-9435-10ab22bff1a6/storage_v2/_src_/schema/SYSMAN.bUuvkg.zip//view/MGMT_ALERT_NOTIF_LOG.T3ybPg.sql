create view MGMT$ALERT_NOTIF_LOG as
  SELECT
	     t.target_name, t.target_type, t.target_guid,
             m.metric_name, m.metric_column, v.policy_guid,m.metric_label,
            CASE
              WHEN m.is_transposed = 0 THEN
                 m.column_label
              ELSE
                 v.key_value
              END,
             v.key_value, null, null, null, null,
             v.message,
             DECODE (v.violation_level, 15, 'Clear',
                                        20, 'Warning',
                                        25, 'Critical', v.violation_level),
             v.violation_level,
             v.collection_timestamp, n.message, n.timestamp,
			 n.source_obj_guid
           FROM mgmt_notification_log n,
                mgmt_targets t,
                mgmt_metrics m,
                mgmt_violations v
           WHERE n.source_obj_type = 1
             AND v.violation_guid = n.source_obj_guid
             AND v.violation_type IN (0,1,2)
             AND m.metric_guid = v.policy_guid
             AND t.target_guid = v.target_guid
             AND m.target_type = t.target_type
             AND m.num_keys < 2
             AND m.type_meta_ver = t.type_meta_ver
             AND (m.category_prop_1 = t.category_prop_1 or m.category_prop_1 = ' ')
             AND (m.category_prop_2 = t.category_prop_2 or m.category_prop_2 = ' ')
             AND (m.category_prop_3 = t.category_prop_3 or m.category_prop_3 = ' ')
             AND (m.category_prop_4 = t.category_prop_4 or m.category_prop_4 = ' ')
             AND (m.category_prop_5 = t.category_prop_5 or m.category_prop_5 = ' ')
	  UNION ALL
	     SELECT
	         t.target_name, t.target_type, t.target_guid,
                 m.metric_name, m.metric_column, v.policy_guid,m.metric_label,
                 CASE
                   WHEN m.is_transposed = 0 THEN
                     m.column_label
                   ELSE
                    k.key_part1_value
                   END,
                 k.key_part1_value, k.key_part2_value,
	         k.key_part3_value, k.key_part4_value, k.key_part5_value,
	         v.message,
                 DECODE (v.violation_level, 15, 'Clear',
                                            20, 'Warning',
                                            25, 'Critical', v.violation_level),
                v.violation_level,
             v.collection_timestamp, n.message, n.timestamp, n.source_obj_guid
           FROM mgmt_notification_log n,
                mgmt_targets t,
		mgmt_metrics m,
                mgmt_violations v,
		mgmt_metrics_composite_keys k
           WHERE n.source_obj_type = 1
             AND v.violation_guid = n.source_obj_guid
             AND v.violation_type IN (0,1,2)
             AND m.metric_guid = v.policy_guid
             AND t.target_guid = v.target_guid
             AND m.target_type = t.target_type
             AND m.num_keys > 1
             AND m.type_meta_ver = t.type_meta_ver
             AND (m.category_prop_1 = t.category_prop_1 or m.category_prop_1 = ' ')
             AND (m.category_prop_2 = t.category_prop_2 or m.category_prop_2 = ' ')
             AND (m.category_prop_3 = t.category_prop_3 or m.category_prop_3 = ' ')
             AND (m.category_prop_4 = t.category_prop_4 or m.category_prop_4 = ' ')
             AND (m.category_prop_5 = t.category_prop_5 or m.category_prop_5 = ' ')
             AND v.target_guid = k.target_guid
             AND v.key_value = k.composite_key
    WITH READ ONLY
/

