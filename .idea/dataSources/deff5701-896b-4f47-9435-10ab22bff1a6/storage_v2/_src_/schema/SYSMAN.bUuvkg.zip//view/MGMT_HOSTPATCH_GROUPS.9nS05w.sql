create view MGMT$HOSTPATCH_GROUPS as
  SELECT t.target_name as group_name,
       g.maturity_level,
       g.need_reboot_pkgs
  FROM mgmt_ecm_hostpatch_groups g,
       mgmt_targets t
 WHERE t.target_guid = g.group_guid
/

