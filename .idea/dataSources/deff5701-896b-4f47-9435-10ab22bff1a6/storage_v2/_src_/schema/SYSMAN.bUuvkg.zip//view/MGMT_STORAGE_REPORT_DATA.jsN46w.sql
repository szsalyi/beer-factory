create view MGMT$STORAGE_REPORT_DATA as
  SELECT
  b.target_name,
  b.target_type,
  a.key_value,
  a.global_unique_id,
  a.name,
  a.storage_layer,
  a.entity_type,
  a.rawsizeb,
  a.sizeb,
  a.usedb,
  a.freeb
FROM mgmt_storage_report_data a,
     mgmt$ecm_current_snapshots b
WHERE  a.ecm_snapshot_id = b.ecm_snapshot_id
AND    b.snapshot_type = 'host_storage'
/

