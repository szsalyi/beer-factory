create view MGMT_V_DB_CONTROLFILES_ECM as
  SELECT	ecm_snapshot_id,
        file_name,
        os_storage_entity
FROM mgmt_db_controlfiles_ecm
/

