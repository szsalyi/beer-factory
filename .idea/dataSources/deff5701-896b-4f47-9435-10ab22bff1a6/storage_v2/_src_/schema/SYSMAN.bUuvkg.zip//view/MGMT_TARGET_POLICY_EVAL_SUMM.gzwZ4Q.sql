create view MGMT$TARGET_POLICY_EVAL_SUMM as
  SELECT t.target_name, t.target_type, t.target_guid,
		   p.policy_name, p.policy_guid, aes.coll_name,
		   aes.last_evaluation_date, aes.total_violations_logged,
		   aes.non_exempt_violations_logged, aes.compliance_score
	  FROM mgmt_targets t,
	       mgmt_policies p,
		   mgmt_policy_assoc_eval_summ aes
	 WHERE t.target_guid = aes.target_guid
	   AND p.policy_guid = aes.policy_guid
	   AND p.policy_type = 2
WITH READ ONLY
/

