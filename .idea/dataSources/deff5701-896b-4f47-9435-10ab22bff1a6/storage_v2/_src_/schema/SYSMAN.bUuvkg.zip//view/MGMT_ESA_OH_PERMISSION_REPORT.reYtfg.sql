create view MGMT$ESA_OH_PERMISSION_REPORT as
  SELECT  tgt.target_guid AS "TARGET_GUID",
        tgt.target_name AS "TARGET_NAME",
        collection.value2 as PRINCIPAL,
        collection.value as OBJECT_NAME
FROM esm_collection_latest collection, mgmt_targets tgt
WHERE property = 'oh_files_perm' AND
        tgt.target_guid = collection.target_guid
/

