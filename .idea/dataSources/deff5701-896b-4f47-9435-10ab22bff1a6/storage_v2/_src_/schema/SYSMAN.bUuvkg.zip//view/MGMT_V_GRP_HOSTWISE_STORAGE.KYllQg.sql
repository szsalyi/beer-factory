create view MGMT_V_GRP_HOSTWISE_STORAGE as
  select tgt.target_name,
       max( decode( met.metric_column, 'db_free',
                    curr.value, 0) ) as db_free,
       max( decode( met.metric_column, 'db_used',
                    curr.value, 0) ) as db_used,
       max( decode( met.metric_column, 'total_allocated',
                    curr.value, 0) ) as total_allocated,
       max( decode( met.metric_column, 'total_unallocated',
                    curr.value, 0) ) as total_unallocated,
       max( decode( met.metric_column, 'total_used',
                    curr.value, 0) ) as total_used,
       max( decode( met.metric_column, 'total_free',
                    curr.value, 0) ) as total_free,
       max( decode( met.metric_column, 'total_overhead',
                    curr.value, 0) ) as total_overhead,
       max( decode( met.metric_column, 'disks_allocated',
                    curr.value, 0) ) as local_disks_allocated,
       max( decode( met.metric_column, 'disks_unallocated',
                    curr.value, 0) ) as local_disks_unallocated,
       max( decode( met.metric_column, 'local_fs_free',
                    curr.value, 0) ) as local_fs_free,
       max( decode( met.metric_column, 'local_fs_used',
                    curr.value, 0) ) as local_fs_used,
       max( decode( met.metric_column, 'writeable_nfs_free',
                    curr.value, 0) ) as writeable_nfs_free,
       max( decode( met.metric_column, 'writeable_nfs_used',
                    curr.value, 0) ) as writeable_nfs_used,
       max( decode( met.metric_column, 'vol_allocated',
                    curr.value, 0) ) as vol_allocated,
       max( decode( met.metric_column, 'vol_unallocated',
                    curr.value, 0) ) as vol_unallocated,
       max( decode( met.metric_column, 'vol_overhead',
                    curr.value, 0) ) as vol_overhead,
       max( decode( met.metric_column, 'asm_allocated',
                    curr.value, 0) ) as asm_allocated,
       max( decode( met.metric_column, 'asm_unallocated',
                    curr.value, 0) ) as asm_unallocated,
       max( decode( met.metric_column, 'asm_overhead',
                    curr.value, 0) ) as asm_overhead
  from mgmt_metrics met,
       mgmt_current_metrics curr,
       mgmt_targets tgt,
       mgmt_storage_report_ui_targets uit
  where uit.ecm_snapshot_id IS NOT NULL
    and uit.target_guid = tgt.target_guid
    and tgt.target_guid = curr.target_guid
    and tgt.target_type = met.target_type
    and met.type_meta_ver = tgt.type_meta_ver
    and met.metric_name = 'host_storage_history'
    and met.metric_guid = curr.metric_guid
    and (met.category_prop_1 = ' ' or
         met.category_prop_1 =  tgt.category_prop_1)
    and (met.category_prop_2 = ' ' or
         met.category_prop_2 =  tgt.category_prop_2)
    and (met.category_prop_3 = ' ' or
         met.category_prop_3 =  tgt.category_prop_3)
    and (met.category_prop_4 = ' ' or
         met.category_prop_4 =  tgt.category_prop_4)
    and (met.category_prop_5 = ' ' or
         met.category_prop_5 =  tgt.category_prop_5)
  group by tgt.target_name
/

