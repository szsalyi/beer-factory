create view MGMT$STORAGE_REPORT_ISSUES as
  SELECT
  b.target_name,
  b.target_type,
  a.type,
  COUNT(*)
FROM mgmt_storage_report_issues a,
     mgmt$ecm_current_snapshots b
WHERE a.ecm_snapshot_id = b.ecm_snapshot_id
AND   b.snapshot_type = 'host_storage'
GROUP BY
  b.target_name,
  b.target_type,
  a.type
/

