create view MGMT_PROVISION_SI_STATUS as
  SELECT
    si.suite_inst_guid, si.name, si.description, si.purpose,
    tgt.current_asn_guid, si.suite_urn, tgt.network_urn, tgt.status,
    smc.member_count
FROM
    mgmt_prov_suite_instance si
INNER JOIN
   mgmt_prov_tgt_status tgt
ON
   si.suite_inst_guid = tgt.prov_tgt_guid
AND
   tgt.prov_target_type = 'suiteInstance'
LEFT OUTER JOIN
   mgmt_prov_suite_hw_cnt smc
ON
   smc.suite_inst_guid = si.suite_inst_guid
WITH READ ONLY
/

