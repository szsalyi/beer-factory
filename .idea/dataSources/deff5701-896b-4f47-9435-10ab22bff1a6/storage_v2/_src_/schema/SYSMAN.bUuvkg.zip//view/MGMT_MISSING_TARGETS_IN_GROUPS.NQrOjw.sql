create view MGMT$MISSING_TARGETS_IN_GROUPS as
  SELECT
  mt.target_name as target_name,
  mt.target_type as target_type,
  mt.target_guid as target_guid,
  gt.target_name as group_name,
  gt.target_type as group_type,
  mt.host_name as host_name,
  mt.type_display_name as type_display_name,
  home_property.property_value as home,
  NVL2(home_property.property_value, 'no_oui_information_diagnostic', 'target_oracle_home_not_found_diagnostic') as diagnostic
FROM
  mgmt_flat_target_assoc m,
  mgmt$target_components c,
  mgmt_target_properties home_property,
  mgmt_targets gt,
  mgmt_targets mt
WHERE
  m.source_target_guid = gt.target_guid
  and m.assoc_target_guid = mt.target_guid
  and m.is_membership = '1'
  and mt.target_type in ('oracle_database', 'oracle_ias')
  and c.target_name(+) = mt.target_name
  and c.target_type(+) = mt.target_type
  and c.target_name is null
  and c.target_type is null
  and mt.target_guid = home_property.target_guid (+)
  and home_property.property_name (+) = 'OracleHome'
/

