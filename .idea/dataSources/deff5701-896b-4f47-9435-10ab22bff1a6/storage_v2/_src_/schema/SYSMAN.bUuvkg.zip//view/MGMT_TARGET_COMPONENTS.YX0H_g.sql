create view MGMT$TARGET_COMPONENTS as
  SELECT
            t.target_name, t.target_type, t.target_guid,
			ho.target_name, h.container_name,
            decode(h.container_type, 'O', 'ORACLE_HOME', 'A', 'APPL_TOP',
                                     'I', 'INDEPENDENT', 'UNKNOWN'),
            h.container_location, c.name, c.external_name,
            decode(vpatch.version, NULL, c.version, vpatch.version),
            c.version, c.is_top_level, s.snapshot_guid
          FROM
             mgmt_targets t,
             mgmt_targets ho,
             mgmt_target_properties p,
             mgmt_ecm_snapshot s,
             mgmt_inv_container h,
             mgmt_inv_component c,
             mgmt_inv_versioned_patch vpatch,
             mgmt_target_type_component_map m
          WHERE ho.target_type = 'host'
            AND ho.target_name = t.host_name
            AND t.target_guid = p.target_guid
            AND p.property_name = 'OracleHome'
            AND s.target_name = ho.target_name
            AND s.is_current = 'Y'
            AND s.snapshot_type = 'host_configuration'
            AND s.snapshot_guid = h.snapshot_guid
            AND h.container_guid = c.container_guid
            AND h.container_location = p.property_value
            AND c.name = m.component_name
            AND m.target_type = t.target_type
            AND c.component_guid = vpatch.component_guid(+)
/

