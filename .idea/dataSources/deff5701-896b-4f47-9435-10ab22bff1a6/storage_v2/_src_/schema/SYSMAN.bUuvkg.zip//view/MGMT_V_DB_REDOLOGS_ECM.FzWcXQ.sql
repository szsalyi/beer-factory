create view MGMT_V_DB_REDOLOGS_ECM as
  SELECT	ecm_snapshot_id,
        file_name,
        logsize,
        os_storage_entity
FROM mgmt_db_redologs_ecm
/

