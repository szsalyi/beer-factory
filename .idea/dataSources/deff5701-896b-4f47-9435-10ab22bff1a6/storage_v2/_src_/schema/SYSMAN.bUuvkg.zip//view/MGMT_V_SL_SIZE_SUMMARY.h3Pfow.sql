create view MGMT_V_SL_SIZE_SUMMARY as
  SELECT storage_layer,
       SUM(top_allocatedb),
       SUM(top_unallocatedb),
       SUM(total_freeb),
       SUM(bottom_sizeb)
FROM   mgmt_v_sl_size a
GROUP BY
   storage_layer
/

