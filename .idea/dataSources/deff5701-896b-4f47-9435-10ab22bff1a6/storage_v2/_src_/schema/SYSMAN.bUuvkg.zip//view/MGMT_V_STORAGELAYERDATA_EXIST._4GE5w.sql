create view MGMT_V_STORAGELAYERDATA_EXIST as
  select max(
           case
             when metric_column in( 'disks_allocated',
                                    'disks_unallocated' )
                  and nvl( value, 0 ) != 0
             then 'Y'
           else 'N'
           end) local_disks_exists,
         max(
           case
             when metric_column in( 'vol_unallocated',
                                    'vol_allocated',
                                    'vol_overhead' )
                  and nvl( value, 0 ) != 0
             then 'Y'
           else 'N'
           end ) volume_exists,
         max(
           case
             when metric_column in ( 'asm_unallocated',
                                     'asm_allocated',
                                     'asm_overhead' )
                  and nvl( value, 0 ) != 0
             then 'Y'
           else 'N'
           end) asm_exists,
         max(
           case
             when metric_column in( 'writeable_nfs_used',
                                    'writeable_nfs_free' )
                  and nvl( value, 0 ) != 0
             then 'Y'
           else 'N'
           end) writeable_nfs_exists,
         max(
           case
             when metric_column in ( 'db_used',
                                     'db_free' )
                  and nvl( value, 0 ) != 0
             then 'Y'
           else 'N'
           end) db_exists,
         max(
           case
             when metric_column in ( 'local_fs_used',
                                     'local_fs_free' )
                  and nvl( value, 0 ) != 0
             then 'Y'
           else 'N'
           end) local_fs_exists
  from mgmt_metrics met,
       mgmt_current_metrics curr,
       mgmt_targets tgt,
       mgmt_storage_report_ui_targets uit
  where uit.ecm_snapshot_id IS NOT NULL
    and uit.target_guid = tgt.target_guid
    and uit.target_type = met.target_type
    and tgt.target_guid = curr.target_guid
    and met.metric_name = 'host_storage_history'
    and met.type_meta_ver = tgt.type_meta_ver
    and (met.category_prop_1 = ' ' or
         met.category_prop_1 =  tgt.category_prop_1)
    and (met.category_prop_2 = ' ' or
         met.category_prop_2 =  tgt.category_prop_2)
    and (met.category_prop_3 = ' ' or
         met.category_prop_3 =  tgt.category_prop_3)
    and (met.category_prop_4 = ' ' or
         met.category_prop_4 =  tgt.category_prop_4)
    and (met.category_prop_5 = ' ' or
         met.category_prop_5 =  tgt.category_prop_5)
    and met.metric_guid = curr.metric_guid
/

