create view MGMT$TARGET_COMPOSITE as
  SELECT
            ct.target_name, ct.target_type,
            t.target_name, t.target_type,' '
          FROM
            mgmt_target_assocs c,
            mgmt_targets t,
            mgmt_targets ct,
            mgmt_target_assoc_defs d
          WHERE d.assoc_guid = c.assoc_guid
            AND ct.target_guid = c.source_target_guid
            AND t.target_guid = c.assoc_target_guid
            AND d.assoc_def_name = 'contains'
            AND d.scope_target_type = ' '
    WITH READ ONLY
/

