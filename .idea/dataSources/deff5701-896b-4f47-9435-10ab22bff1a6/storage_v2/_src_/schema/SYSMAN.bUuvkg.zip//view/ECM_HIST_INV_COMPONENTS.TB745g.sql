create view ECM$HIST_INV_COMPONENTS as
  SELECT
  h.snapshot_guid AS ecm_snapshot_id,
  c.name,
  c.version,
  h.container_location,
  c.description,
  NVL(c.external_name,c.name) AS external_name,
  c.languages,
  c.installed_location,
  c.installer_version,
  c.min_deinstaller_version,
  c.is_top_level,
  c.timestamp,
  NVL(p.version,c.version) AS patch_version
FROM
  mgmt_inv_component c,
  mgmt_inv_container h,
  mgmt_inv_versioned_patch p
WHERE c.container_guid = h.container_guid
  AND c.component_guid = p.component_guid(+)
WITH READ ONLY
/

