create view MGMT$TARGET_TYPE as
  SELECT
          t.target_name, t.target_type, t.target_guid,  t.type_meta_ver,
          t.category_prop_1, t.category_prop_2, t.category_prop_3,
          t.category_prop_4, t.category_prop_5, metric_name,
          metric_column, metric_guid,key_column,
          DECODE (metric_type, 0, 'Number', 1, 'String', 2, 'Table',
                               3, 'Raw', 4, 'External', 5, 'Repository Metric'),
          metric_label, column_label, description,description_nlsid,unit,
          unit_nlsid,short_name,short_name_nlsid,display_name,type_display_name
        FROM
            mgmt_metrics m, mgmt_targets t
        WHERE
            t.target_type = m.target_type
            and t.type_meta_ver = m.type_meta_ver
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
    WITH READ ONLY
/

