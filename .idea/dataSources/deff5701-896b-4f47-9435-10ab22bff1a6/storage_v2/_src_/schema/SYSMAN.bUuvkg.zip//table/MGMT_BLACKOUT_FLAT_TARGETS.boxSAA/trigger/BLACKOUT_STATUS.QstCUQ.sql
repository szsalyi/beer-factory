create trigger BLACKOUT_STATUS
  after update
  on MGMT_BLACKOUT_FLAT_TARGETS
  for each row
  DECLARE
  l_created_thru MGMT_BLACKOUTS.created_thru%TYPE;
  l_occurrence_number MGMT_BLACKOUTS.occurrence_number%TYPE;
  l_status MGMT_BLACKOUTS.blackout_status%TYPE;
BEGIN
    SELECT  created_thru, occurrence_number
    INTO    l_created_thru, l_occurrence_number
    FROM    MGMT_BLACKOUTS
    WHERE   blackout_guid=:new.blackout_guid;

    IF l_created_thru IS NULL THEN
        -- Compute the new status
        IF :new.job_status=MGMT_BLACKOUT_ENGINE.BLK_JSTATE_START_PROCESSING THEN
            l_status := MGMT_BLACKOUT.BLK_STATE_START_PENDING;
        ELSIF :new.job_status=MGMT_BLACKOUT_ENGINE.BLK_JSTATE_STOPPED THEN
            l_status := MGMT_BLACKOUT.BLK_STATE_ENDED;
        ELSE
            l_status := MGMT_BLACKOUT.BLK_STATE_STARTED;
        END IF;

        -- Update entries in the blackout window table. We only
        -- need to update "active" entries, ones that are
        -- not in state stopped or ended.
        UPDATE  MGMT_BLACKOUT_WINDOWS
        SET     status=l_status
        WHERE   blackout_guid=:new.blackout_guid
        AND     occurrence_number=l_occurrence_number
        AND     target_guid=:new.target_guid
        AND     status NOT IN (MGMT_BLACKOUT.BLK_STATE_STOPPED,
                               MGMT_BLACKOUT.BLK_STATE_ENDED);
    END IF;

END;
/

