create view ECM$HIST_NIC_DETAILS as
  SELECT
  snapshot_guid AS ecm_snapshot_id,
  name,
  flags,
  max_transfer_unit,
  inet_address,
  mask,
  broadcast_address,
  mac_address,
  hostname_aliases
FROM
  mgmt_hc_nic_details
WITH READ ONLY
/

