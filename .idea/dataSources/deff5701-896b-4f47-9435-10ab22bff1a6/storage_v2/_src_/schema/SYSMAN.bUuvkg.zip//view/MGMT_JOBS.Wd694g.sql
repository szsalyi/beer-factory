create view MGMT$JOBS as
  SELECT
           j.job_name, j.job_id, j.job_owner, j.job_description,
           j.job_type, j.target_type, j.is_library, j.restartable,
           s.start_time, s.end_time,
           DECODE (s.timezone_info,
                    1, 'Repository',
                    2, 'Agent',
                    3, 'Specified Offset/Region',
                    4, 'Specified Offset/Region',
                    s.timezone_info),
           DECODE(s.timezone_info, 3, s.timezone_offset,
                  s.timezone_region),
           DECODE (s.frequency_code, 1, 'One Time',
                                     2, 'Interval',
                                     3, 'Daily',
                                     4, 'Weekly',
                                     5, 'Monthy',
                                     6, 'Yearly'),
           s.interval, s.execution_hours, s.execution_minutes,
           s.months, s.days
        FROM
            mgmt_job j,
            mgmt_job_schedule s
        WHERE
            j.schedule_id = s.schedule_id AND
            j.system_job = 0 AND
            j.nested=0 AND
            j.is_corrective_action=0
    WITH READ ONLY
/

