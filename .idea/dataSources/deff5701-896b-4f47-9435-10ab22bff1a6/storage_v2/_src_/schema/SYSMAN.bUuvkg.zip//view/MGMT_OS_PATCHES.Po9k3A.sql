create view MGMT$OS_PATCHES as
  select
  t.target_name as host,
  o.name || ' ' || o.base_version || ' ' || o.update_level || '(' || o.address_length_in_bits || ')' as os_extended,
  o.name || ' ' || o.base_version as os,
  p.name as patch
from
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_os_summary o,
  mgmt_hc_os_components p
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = o.snapshot_guid and
  s.snapshot_guid = p.snapshot_guid and
  p.type = 'Patch'
/

