create view MGMT$DELTA_VIEW_DETAILS as
  select
    MGMT_DELTA.GET_DELTA_KEY_DISPLAY_STRING( i.row_guid ) as key_path,
    e.delta_time as delta_time,
    e.operation as operation,
    i.COLLECTION_TYPE as COLLECTION_TYPE,
    d.name as attribute_name,
    d.value as new_value,
    d.old_value as old_value
  from
    mgmt_delta_entry e,
    mgmt_delta_ids i,
    mgmt_delta_entry_values d,
    mgmt_targets t,
    mgmt_ecm_snapshot_metadata md,
    mgmt_ecm_snapshot_md_tables mdt,
    mgmt_delta_snap p
  where
    i.row_guid = e.row_guid
    and e.delta_entry_guid = d.delta_entry_guid(+)
    and p.delta_guid = e.delta_guid
    and p.new_left_target_name = t.target_name
    and p.target_type = t.target_type
    and p.delta_type = 'HISTORY'
    and p.target_type = md.target_type
    and p.snapshot_type = md.snapshot_type
    and md.kind = 'P'
    and md.history_ui_on = 'Y'
    and md.metadata_id = mdt.metadata_id
    and mdt.name = i.collection_type
    and mdt.history_ui_on = 'Y'
    AND (exists (select * from mgmt_ecm_snapshot_md_columns mdc
          where mdc.metadata_id = md.metadata_id
            AND mdc.table_name = mdt.name
            AND mdc.name = d.name
            AND mdc.history_ui_on = 'Y')
      OR d.name is null)
/

