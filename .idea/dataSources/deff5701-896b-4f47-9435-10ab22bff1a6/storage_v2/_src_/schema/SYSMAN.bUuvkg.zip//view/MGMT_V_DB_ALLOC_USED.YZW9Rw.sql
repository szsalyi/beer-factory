create view MGMT_V_DB_ALLOC_USED as
  SELECT tgt.target_name,
         tgt.target_type,
         tbspAlloc.ALLOCATED_SPACE  allocated,
         tbspUsed.USED_SPACE  used
    FROM
       (SELECT tg.target_guid,
          ROUND(SUM(m.value * 1024 * 1024), 2)   AS ALLOCATED_SPACE
        FROM
         mgmt$metric_current m,
         mgmt_v_host_dbs tg
       WHERE
         m.metric_name='tbspAllocation' AND
         m.metric_column='spaceAllocated'  AND
         m.target_guid=tg.target_guid  group by tg.target_guid) tbspAlloc,
      (SELECT tg.target_guid,
          ROUND(SUM(m.value * 1024 * 1024), 2)   AS USED_SPACE
        FROM
         mgmt$metric_current m,
         mgmt_v_host_dbs tg
       WHERE
         m.metric_name='tbspAllocation' AND
         m.metric_column='spaceUsed'  AND
         m.target_guid=tg.target_guid  group by tg.target_guid) tbspUsed,
         mgmt_v_host_dbs tgt
  WHERE tgt.target_guid = tbspAlloc.target_guid and
	tgt.target_guid = tbspUsed.target_guid
/

