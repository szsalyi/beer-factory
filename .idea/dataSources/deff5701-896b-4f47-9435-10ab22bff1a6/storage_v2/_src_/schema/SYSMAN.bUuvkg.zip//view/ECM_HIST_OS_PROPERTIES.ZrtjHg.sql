create view ECM$HIST_OS_PROPERTIES as
  SELECT
  snapshot_guid AS ecm_snapshot_id,
  type,
  name,
  value
FROM mgmt_hc_os_properties
WITH READ ONLY
/

