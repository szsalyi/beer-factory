create view MGMT$ORACLE_SW_ENT_INSTALL as
  SELECT
  map.target_type as target_type,
  map.property_name as pname,
  map.property_value as pvalue,
  component.external_name as external_name,
  case when ps_patch.version is null then component.version else ps_patch.version end as version,
              host.target_name as host_name,
              host.target_guid as htguid,
              container_location,
              case
                when
                  exists
                  (
                    SELECT *
                    FROM mgmt_inv_patch p
                    WHERE p.container_guid = home.container_guid
                  )
                then 1 else 0
              end as num_patched,
              home.container_guid as container_guid
FROM
  mgmt_targets host,
  mgmt_ecm_snapshot snapshot,
  mgmt_inv_container home,
  mgmt_inv_component component,
  mgmt_inv_versioned_patch ps_patch,
  mgmt_target_type_component_map map
WHERE host.target_type = 'host'
  and host.target_name = snapshot.target_name
  and host.target_type = snapshot.target_type
  and snapshot.snapshot_type = 'host_configuration'
  and snapshot.is_current = 'Y'
  and home.snapshot_guid = snapshot.snapshot_guid
  and component.container_guid = home.container_guid
  and component.component_guid = ps_patch.component_guid(+)
  and map.component_name = component.name
  and ((map.property_name IS NULL and map.property_value IS NULL))
/

