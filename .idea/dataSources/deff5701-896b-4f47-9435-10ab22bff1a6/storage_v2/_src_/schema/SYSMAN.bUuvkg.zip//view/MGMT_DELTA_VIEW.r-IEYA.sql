create view MGMT$DELTA_VIEW as
  select
    MGMT_DELTA.GET_DELTA_KEY_DISPLAY_STRING( i.row_guid ) as key_path,
    e.delta_time as delta_time,
    e.operation as operation,
    i.COLLECTION_TYPE as COLLECTION_TYPE,
    MGMT_DELTA.GET_DELTA_VALUE_DISPLAY_STRING( e.delta_entry_guid, e.operation ) as delta_values
  from
    mgmt_delta_entry e,
    mgmt_delta_ids i,
    mgmt_targets t,
    mgmt_ecm_snapshot_metadata md,
    mgmt_ecm_snapshot_md_tables mdt,
    mgmt_delta_snap p
  where
    i.row_guid = e.row_guid
    and p.delta_guid = e.delta_guid
    and p.new_left_target_name = t.target_name
    and p.target_type = t.target_type
    and p.delta_type = 'HISTORY'
    and p.target_type = md.target_type
    and p.snapshot_type = md.snapshot_type
    and md.kind = 'P'
    and md.history_ui_on = 'Y'
    and md.metadata_id = mdt.metadata_id
    and mdt.name = i.collection_type
    and mdt.history_ui_on = 'Y'
/

