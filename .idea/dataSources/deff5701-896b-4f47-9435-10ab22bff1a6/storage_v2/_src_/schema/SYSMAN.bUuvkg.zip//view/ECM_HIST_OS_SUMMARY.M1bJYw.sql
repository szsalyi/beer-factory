create view ECM$HIST_OS_SUMMARY as
  SELECT
  snapshot_guid AS ecm_snapshot_id,
  name,
  vendor_name,
  base_version,
  update_level,
  distributor_version,
  max_swap_space_in_mb,
  address_length_in_bits
FROM mgmt_hc_os_summary
WITH READ ONLY
/

