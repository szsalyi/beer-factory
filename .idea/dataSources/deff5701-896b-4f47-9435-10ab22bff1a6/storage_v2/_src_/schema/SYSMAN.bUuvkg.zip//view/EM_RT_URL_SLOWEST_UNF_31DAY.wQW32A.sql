create view EM$RT_URL_SLOWEST_UNF_31DAY as
  SELECT m.source_TARGET_GUID,
         ct.TARGET_NAME, ct.TARGET_TYPE,
         d.METRIC_NAME,
         nvl(max((SELECT display_name FROM MGMT_RT_URLS u
           WHERE u.target_guid = m.source_target_guid
           AND u.url_filename = d.url_filename)), d.url_filename) "DISPLAY_NAME",
         d.URL_FILENAME, max(URL_LINK),
         sum(response_time_average*hits)/sum(hits), min(response_time_minimum),
         max(response_time_maximum), sum(RESPONSE_TIME_SDEV*hits)/sum(hits),
         sum(hits)
    FROM MGMT_RT_URL_1DAY d, MGMT_TARGET_ASSOCS m,
         MGMT_TARGETS ct, MGMT_TARGET_ASSOC_DEFS def
    WHERE
     d.target_guid = m.assoc_target_guid
     AND def.assoc_guid = m.assoc_guid
     AND def.assoc_def_name = 'supports_eum_on'
     AND def.scope_target_type = ' '
     AND ct.target_guid = m.source_target_guid
    GROUP BY m.source_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        d.METRIC_NAME,
        d.URL_FILENAME
    ORDER BY sum(response_time_average*hits)/sum(hits) DESC
/

