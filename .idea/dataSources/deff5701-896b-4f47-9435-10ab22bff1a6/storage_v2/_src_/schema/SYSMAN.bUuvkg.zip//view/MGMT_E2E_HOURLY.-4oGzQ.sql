create view MGMT$E2E_HOURLY as
  SELECT "URI","HIT_COUNT","TOTAL_TIME","SERVLET_COUNT","SERVLET_TIME","JSP_COUNT","JSP_TIME","EJB_COUNT","EJB_TIME","JDBC_TIME","TARGET_GUID","ROLLUP_TIMESTAMP" FROM (
SELECT uri, hit_count, total_time, servlet_count,
servlet_time, jsp_count, jsp_time, ejb_count, ejb_time, jdbc_time,
mt.target_guid,rollup_timestamp
FROM   mgmt_e2e_summary_1hour e2e,mgmt_target_assocs mta,
mgmt_target_assoc_defs mdef, mgmt_targets mt
WHERE
e2e.target_guid = mta.assoc_target_guid
AND source_target_guid = mt.target_guid
AND mta.assoc_guid = mdef.assoc_guid
AND mdef.assoc_def_name = 'supports_e2e_on'
AND mdef.scope_target_type = ' ')
/

