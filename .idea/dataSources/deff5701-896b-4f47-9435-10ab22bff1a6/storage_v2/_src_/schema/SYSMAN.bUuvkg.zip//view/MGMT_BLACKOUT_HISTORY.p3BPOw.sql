create view MGMT$BLACKOUT_HISTORY as
  SELECT b.blackout_name, b.created_by, b.blackout_guid,
              decode(h.start_time, null, null,
                     MGMT_GLOBAL.adjust_tz(h.start_time,
                                NVL(s.timezone_region,
                                ((s.timezone_offset/60)||':'||mod(s.timezone_offset,60))),
                                t.timezone_region)),
              decode(h.end_time, null, null,
                     MGMT_GLOBAL.adjust_tz(h.end_time,
                                NVL(s.timezone_region,
                                ((s.timezone_offset/60)||':'||mod(s.timezone_offset,60))),
                                t.timezone_region)),
              t.target_name, t.target_type, t.target_guid,
              DECODE(b.blackout_status,
                      0, 'Scheduled',
                      1, 'Start Processing',
                      2, 'Start Partial',
                      4, 'Started',
                      5, 'Stop Pending',
                      6, 'Stop Failed',
                      7, 'Stop Partial',
                      8, 'Edit Failed',
                      9, 'Edit Partial',
                     10, 'Stopped',
                     11, 'Ended',
                     12, 'Partial Blackout',
                     13, 'Modify Pending', b.blackout_status)
       FROM   MGMT_BLACKOUTS b,
              MGMT_BLACKOUT_HISTORY h,
              MGMT_BLACKOUT_FLAT_TARGETS ft,
              MGMT_TARGETS t,
              MGMT_BLACKOUT_SCHEDULE s
       WHERE  b.blackout_guid=h.blackout_guid
       AND    h.blackout_guid=ft.blackout_guid
       AND    ft.target_guid=t.target_guid
       AND    b.blackout_guid=s.blackout_guid
       WITH READ ONLY
/

