create view MGMT$TARGET_PROPERTIES as
  SELECT
          t.target_name, t.target_type, t.target_guid,
          p.property_name, p.property_value, p.property_type
        FROM
            mgmt_targets t,
            mgmt_target_properties p
        WHERE
            t.target_guid = p.target_guid
    WITH READ ONLY
/

