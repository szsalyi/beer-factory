create view MGMT$METRIC_ERROR_CURRENT as
  SELECT t.target_name, t.target_type, t.target_guid,
           m.metric_name, cme.metric_guid,m.metric_label, cme.coll_name,
           cme.collection_timestamp, DECODE(cme.metric_error_type, 0,
           'Error', 1, 'Warning', 'Unknown'),
           cme.metric_error_message
      FROM mgmt_targets t,
	       mgmt_metrics m,
		   mgmt_current_metric_errors cme
     WHERE t.target_guid = cme.target_guid
       and m.metric_guid = cme.metric_guid
       and t.target_type = m.target_type
       and t.type_meta_ver = m.type_meta_ver
       and (t.category_prop_1 = m.category_prop_1 or m.category_prop_1 =
' ')
       and (t.category_prop_2 = m.category_prop_2 or m.category_prop_2 =
' ')
       and (t.category_prop_3 = m.category_prop_3 or m.category_prop_3 =
' ')
       and (t.category_prop_4 = m.category_prop_4 or m.category_prop_4 =
' ')
       and (t.category_prop_5 = m.category_prop_5 or m.category_prop_5 =
' ')
 WITH READ ONLY
/

