create view MGMT$CPF_PATCH_INFO as
  select
        data.ap_guid   	       as patch_ap_guid,
	data.patch_guid	       as patch_guid,
        data.patch_id          as patch_id,
        data.release_id        as patch_release_id,
        data.platform_id       as patch_platform_id,
        data.product_id        as patch_product_id,
        data.patch_type        as patch_type,
        data.bug_number        as patch_fixes_bug,
        decode(pc.patch_id,
               null, 'N',
               'Y')            as patch_valid_status
from
        (select
                ap.ap_guid,
                pp.patch_guid,
                ap.patch_id,
                ap.release_id,
                pp.platform_id,
                ap.product_id,
                ap.patch_type,
                pfb.bug_number
         from   mgmt_bug_available_patch   ap,
                mgmt_bug_patch_platform    pp,
                mgmt_bug_patch_fixes_bug   pfb
         where  ap.ap_guid = pp.ap_guid and
                ap.ap_guid = pfb.ap_guid)         data,
         mgmt_bug_patch_certificate               pc
where
        data.patch_id = pc.patch_id (+) and
        data.release_id = pc.release_id (+) and
        data.platform_id = pc.platform_id (+)
order by
        data.patch_id,
        data.release_id,
        data.platform_id
/

