create view MGMT$CSM_WATCHLIST as
  SELECT
  tg.target_name, tg.target_type,
  wl.display_name, wl.url_filename, wl.description
FROM
  MGMT_TARGETS tg,
  MGMT_RT_URLS wl
WHERE
  tg.target_guid = wl.target_guid
WITH READ ONLY
/

