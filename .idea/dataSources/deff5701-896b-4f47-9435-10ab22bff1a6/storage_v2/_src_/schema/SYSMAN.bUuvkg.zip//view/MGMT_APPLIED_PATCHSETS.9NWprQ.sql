create view MGMT$APPLIED_PATCHSETS as
  SELECT
  patchset.version,
  NVL(patchset.external_name,patchset.name) as name,
  patchset.timestamp,
  snap.target_name as host,
  con.container_name as home_name,
  con.container_location as home_location,
  con.container_guid,
  tgt.target_guid
FROM
  mgmt_inv_container con,
  mgmt_ecm_snapshot snap,
  mgmt_inv_patchset patchset,
  mgmt_targets tgt
WHERE
  con.snapshot_guid = snap.snapshot_guid   AND
  snap.is_current = 'Y'   AND
  snap.snapshot_type = 'host_configuration'    AND
  con.container_guid = patchset.container_guid   AND
  tgt.target_name = snap.target_name
WITH READ ONLY
/

