create view ECM$OS_SUMMARY as
  select
  snapshot_guid as ecm_snapshot_id,
  name,
  vendor_name,
  base_version,
  update_level,
  distributor_version,
  address_length_in_bits,
  max_swap_space_in_mb
from MGMT_HC_OS_SUMMARY
/

