create trigger ALL_TARGET_PROPS_TR
  before insert or update
  on MGMT_ALL_TARGET_PROPS
  for each row
  BEGIN
  IF :new.property_display_name IS NULL THEN
    :new.property_display_name := :new.property_name;
  END IF;
END;
/

