create view MGMT$SOFTWARE_HOMES as
  SELECT
  t.target_name as host_name,
  c.container_name as home_name,
  decode(c.container_type, 'O', 'ORACLE_HOME', 'A', 'APPL_TOP',
        'I', 'INDEPENDENT', 'UNKNOWN') as home_type,
  c.container_location as home_location,
  s.snapshot_guid
FROM
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_inv_container c
WHERE t.target_type = 'host'
  AND s.target_name = t.target_name
  AND s.is_current = 'Y'
  AND s.snapshot_type = 'host_configuration'
  AND s.snapshot_guid = c.snapshot_guid
/

