create view MGMT_V_HOST_DBS as
  SELECT tgt.host_name, snap.target_name, snap.target_guid,
         snap.ecm_snapshot_id, snap.target_type, tgt.emd_url
    FROM MGMT$ECM_CURRENT_SNAPSHOTS snap,
         MGMT_TARGETS tgt,
         MGMT_STORAGE_REPORT_UI_TARGETS uit
   WHERE uit.ecm_snapshot_id IS NOT NULL
     AND uit.target_name = tgt.host_name
     AND tgt.target_type = 'rac_database'
     AND tgt.target_guid = snap.target_guid
     AND snap.snapshot_type = 'oracle_racconfig'
   UNION ALL
  SELECT tgt.host_name, snap.target_name, snap.target_guid,
         snap.ecm_snapshot_id, snap.target_type, tgt.emd_url
    FROM MGMT$ECM_CURRENT_SNAPSHOTS snap,
         MGMT_TARGETS tgt,
         MGMT_STORAGE_REPORT_UI_TARGETS uit
   WHERE uit.ecm_snapshot_id IS NOT NULL
     AND uit.target_name = tgt.host_name
     AND tgt.target_type = 'oracle_database'
     AND tgt.target_guid = snap.target_guid
     AND snap.snapshot_type = 'oracle_dbconfig'
     AND NOT EXISTS
         (
           SELECT member_target_name
             FROM MGMT_TARGET_MEMBERSHIPS
            WHERE member_target_guid = tgt.target_guid
              AND composite_target_type = 'rac_database'
         )
/

