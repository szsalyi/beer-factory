create view EM$RT_URL_SLOWEST_31DAY as
  SELECT "COMPOSITE_TARGET_GUID","COMPOSITE_TARGET_NAME","COMPOSITE_TARGET_TYPE","METRIC_NAME","DISPLAY_NAME","URL_FILENAME","URL_LINK","RESPONSE_TIME_AVERAGE","RESPONSE_TIME_MINIMUM","RESPONSE_TIME_MAXIMUM","RESPONSE_TIME_STDDEV","HITS" from em$rt_url_slowest_unf_31day d
    WHERE d.hits >= NVL((SELECT property_value
                            FROM mgmt_rt_target_properties pro
                            WHERE pro.target_guid = d.composite_target_guid
                              AND pro.property_name = 'mgmt_rt_min_hits'), (
          SELECT parameter_value
              FROM mgmt_parameters
              WHERE parameter_name = 'mgmt_rt_min_hits'))
/

