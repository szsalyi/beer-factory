create view EM$RT_URL_RAW_SLOWEST_31DAY as
  SELECT
        m.source_target_guid,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        m.assoc_target_guid,
        r.metric_name,
        nvl(
          (SELECT u.display_name FROM MGMT_RT_URLS u WHERE
              m.source_target_guid = u.target_guid AND
              u.url_filename = r.url_filename),
           r.url_filename),
        r.url_filename,
        r.url_link,
        r.visitor_node,
        r.visitor_domain,
        SUBSTR(r.visitor_ip, 1, INSTR(r.visitor_ip, '.', 1, 3)-1) "VISITOR_SUBNET",
        r.visitor_ip_num,
        r.visitor_ip,
        r.collection_timestamp,
        round(r.elapsed_time/1000,2),
        r.submit_action_timestamp,
        r.os_name,
        r.os_version,
        r.browser_name,
        r.browser_version
    FROM em$rt_raw r,
         MGMT_TARGET_ASSOCS m,
         MGMT_TARGETS ct,
         MGMT_TARGET_ASSOC_DEFS def
    WHERE r.target_guid = m.assoc_target_guid
      AND r.elapsed_time <= NVL((SELECT property_value
                            FROM mgmt_rt_target_properties pro
                            WHERE pro.target_guid = r.target_guid
                              AND pro.property_name = 'mgmt_rt_max_elapsed_time'), (
                      SELECT parameter_value
                      FROM mgmt_parameters
                      WHERE parameter_name = 'mgmt_rt_max_elapsed_time'))
      AND def.assoc_guid = m.assoc_guid
      AND def.assoc_def_name = 'supports_eum_on'
      AND def.scope_target_type = ' '
      AND ct.target_guid  = m.source_target_guid
    ORDER BY r.elapsed_time DESC
/

