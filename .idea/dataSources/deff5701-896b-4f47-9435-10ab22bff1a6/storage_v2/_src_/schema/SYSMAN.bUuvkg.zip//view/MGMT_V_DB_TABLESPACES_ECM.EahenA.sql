create view MGMT_V_DB_TABLESPACES_ECM as
  SELECT	ecm_snapshot_id,
        tablespace_size,
        tablespace_used_size
FROM    mgmt_db_tablespaces_ecm
/

