create view MGMT$TEMPLATES as
  SELECT tt.target_type, tt.template_name, tt.template_guid,
           tt.description, tt.owner, tt.is_public, tt.created_date,
           tt.last_updated_date, tt.last_updated_by
      FROM mgmt_templates tt
WITH READ ONLY
/

