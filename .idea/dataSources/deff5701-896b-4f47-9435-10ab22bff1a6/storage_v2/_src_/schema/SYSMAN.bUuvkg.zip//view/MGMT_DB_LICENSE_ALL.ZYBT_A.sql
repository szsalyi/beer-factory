create view MGMT$DB_LICENSE_ALL as
  select
  g.host_name,
  s.ecm_snapshot_id as snapshot_guid,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  s.is_current,
  f.SESSIONS_MAX,
  f.SESSIONS_WARNING,
  f.SESSIONS_CURRENT,
  f.SESSIONS_HIGHWATER,
  f.USERS_MAX
from
  mgmt_targets g,
  mgmt_db_license_ecm f,
  mgmt$ecm_visible_snapshots s
where
  s.ecm_snapshot_id = f.ecm_snapshot_id and
  s.target_guid = g.target_guid (+)
/

