create view MGMT$ECM_CONFIG_HISTORY_KEY1 as
  SELECT -- UNIQUE
 e.delta_time AS DELTATIME,
 e.delta_entry_guid AS DELTAGUID,
 g.timezone_region AS TIMEZONE,
 g.target_name AS TARGET_NAME,
 g.host_name AS HOSTNAME,
 g.target_type AS TARGET_TYPE,
 p.snapshot_type AS SNAPSHOTTYPE,
 i.collection_type AS COLLECTIONTYPE,
 t.full_table_path AS TABLE_PATH,
 p.target_type || '|' || p.snapshot_type || '|' || t.full_table_path || '|L' AS CATEGORY,
 e.operation AS OPERATION,
 iv1.value AS KEY1,
 d.name AS ATTRIBUTE,
 d.value AS NEWVALUE,
 d.old_value AS OLDVALUE
 FROM
  mgmt_ecm_md_hist_tbls t,
  mgmt_delta_entry e,
  mgmt_delta_entry_values d,
  mgmt_delta_ids i,
  mgmt_delta_id_values iv1,
  mgmt_delta_snap p,
  mgmt_targets g
 WHERE t.num_hist_ui_keys = 1
   AND t.target_type = p.target_type
   AND t.snapshot_type = p.snapshot_type
   AND t.name = i.collection_type
   AND p.delta_type = 'HISTORY'
   AND e.row_guid = i.row_guid
   AND e.delta_entry_guid = d.delta_entry_guid(+)
   AND e.operation != 'SAME'
   AND ((e.operation != 'UPDATE') OR NOT(NVL(d.value,' ') = NVL(d.old_value,' ')))
   AND p.delta_guid = e.delta_guid
   AND p.new_left_target_name = g.target_name
   AND p.target_type = g.target_type
   AND iv1.delta_ids_guid = i.row_guid
   AND iv1.name = t.hist_ui_key1
   AND (exists (select * from mgmt_ecm_snapshot_md_columns mdc
          where mdc.metadata_id = t.metadata_id
            AND mdc.table_name = t.name
            AND mdc.name = d.name
            AND mdc.history_ui_on = 'Y')
      OR d.name is null)
WITH READ ONLY
/

