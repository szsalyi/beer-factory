create view MGMT$ESA_OH_OWNERSHIP_REPORT as
  SELECT  targets.target_guid AS "TARGET_GUID",
        targets.target_name AS "TARGET_NAME",
        collection.value2 as PRINCIPAL,
        collection.value as OBJECT_NAME
FROM esm_collection_latest collection, mgmt_targets targets
WHERE collection.target_guid = targets.target_guid and
      property = 'oh_bin_files_owner'
/

