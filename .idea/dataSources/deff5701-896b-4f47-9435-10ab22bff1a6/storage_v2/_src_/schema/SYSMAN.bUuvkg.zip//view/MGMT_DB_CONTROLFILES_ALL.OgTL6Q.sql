create view MGMT$DB_CONTROLFILES_ALL as
  select
  g.host_name,
  s.ecm_snapshot_id as snapshot_guid,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  s.is_current,
  c.file_name,
  c.status,
  c.creation_date,
  c.sequence_num,
  c.change_num,
  c.mod_date,
  c.os_storage_entity
from
  mgmt_targets g,
  mgmt_db_controlfiles_ecm c,
  mgmt$ecm_visible_snapshots s
where
  s.ecm_snapshot_id = c.ecm_snapshot_id and
  s.target_guid = g.target_guid (+)
/

