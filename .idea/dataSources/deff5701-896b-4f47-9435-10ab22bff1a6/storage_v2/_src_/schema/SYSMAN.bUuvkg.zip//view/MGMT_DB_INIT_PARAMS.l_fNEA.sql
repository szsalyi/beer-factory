create view MGMT$DB_INIT_PARAMS as
  select
  g.host_name,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  p.name as name,
  p.isdefault,
  p.value,
  ecm_util.GET_GENERIC_VALS_DATATYPE( p.value ) as datatype
from
  mgmt_targets g,
  mgmt_db_init_params_ecm p,
  mgmt_ecm_gen_snapshot s
where
  s.snapshot_guid = p.ecm_snapshot_id and
  s.target_guid = g.target_guid and
  s.is_current = 'Y'
/

