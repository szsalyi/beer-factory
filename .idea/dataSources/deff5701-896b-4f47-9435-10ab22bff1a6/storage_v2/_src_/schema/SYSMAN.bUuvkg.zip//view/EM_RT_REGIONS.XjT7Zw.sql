create view EM$RT_REGIONS as
  SELECT  r.target_guid,
    r.region_name, r.description,
    e.domain, DECODE(e.min_ip, -1, 'D', 'S')
  FROM MGMT_RT_REGIONS r, MGMT_RT_REGION_MAPPING m, MGMT_RT_REGION_ENTRIES e
  WHERE m.region_guid = r.region_guid
    AND m.id = e.id
/

