create view MGMT$CSA_COLLECTIONS as
  SELECT
       s.display_target_name,
       (s.display_target_name || NVL2(info.target_key1, '; ' || target_key1, '')
                              || NVL2(info.target_key2, '; ' || target_key2, '')
                              || NVL2(info.target_key3, '; ' || target_key3, '')) as csaclient,
       s.start_timestamp as collection_timestamp,
       FROM_TZ(CAST(s.start_timestamp as TIMESTAMP), os.timezone_region) AT LOCAL as adj_timestamp,
       csa.NET_IP,
       csa.NET_EFFECTIVE_IP,
       s.message as collection_message,
       info.os_user_name,
       info.hostname,
       info.domain,
       NVL2(info.domain,
            (CASE WHEN info.hostname LIKE '%' || info.domain THEN info.hostname ELSE info.hostname
                                              || '.' || info.domain END),
            info.hostname) as host,
       info.boot_disk_volume_serial_num,
       info.worst_rule_status as compliance,
       info.appid as appid,
       csa.NET_SUBNET,
       csa.NET_LATENCY_IN_MS,
       csa.NET_BANDWIDTH_IN_KBITPS,
       csa.BROWSER_TYPE,
       csa.BROWSER_VERSION,
       csa.browser_type || ' ' || csa.browser_version as browser,
       csa.BROWSER_JVM_VENDOR,
       csa.BROWSER_JVM_VERSION,
       csa.BROWSER_PROXY_SERVER,
       csa.BROWSER_PROXY_EXCEPTIONS,
       csa.BROWSER_CACHE_SIZE_IN_MB,
       csa.BROWSER_CACHE_UPDATE_FRQ,
       csa.BROWSER_HTTP1_1_SUPPORT,
       csa.REFERRING_URL_HEADER,
       csa.REFERRING_URL_PARAMS,
       csa.referring_url_header || NVL2(referring_url_params, '?' || referring_url_params, '') as refurl,
       csa.CSA_URL_HEADER,
       csa.CSA_URL_PARAMS,
       csa.csa_url_header || NVL2(csa_url_params, '?' || csa_url_params, '') as csaurl,
       csa.DESTINATION_URL_HEADER,
       csa.DESTINATION_URL_PARAMS,
       csa.destination_url_header || NVL2(destination_url_params, '?' || destination_url_params, '') as desturl,
       csa.CONNECTION_TYPE,
       csa.IS_WINDOWS_ADMIN,
       csa.WINDOWS_DOMAIN,
       csa.BROWSER_PROXY_ENABLED,
       csa.AUTO_CONFIG_URL,
       ( select count(*)
         from mgmt_ecm_csa_cookies c
         where s.snapshot_guid = c.ecm_snapshot_id ) as number_of_cookies,
       ( select count(*)
         from mgmt_ecm_csa_custom c
         where s.snapshot_guid = c.ecm_snapshot_id ) as number_of_custom_values,
       hw.system_config || ' ' || hw.machine_architecture || ', ' || hw.memory_size_in_mb || 'MB RAM ('
                        || hw.avail_memory_size_in_mb || ' free), ' || hw.local_disk_space_in_gb || 'GB HD ('
                        || hw.avail_local_disk_space_in_gb || ' free)'
			|| NVL2(hw.clock_freq_in_mhz, ', ' || hw.clock_freq_in_mhz || 'MHz FSB', '')
			|| NVL2(hw.cpu_count, ', ' || hw.cpu_count || ' CPUs', '')
			|| NVL2(hw.vendor_name, ', ' || hw.vendor_name, '') as hardware,
       hw.vendor_name as hardware_vendor_name,
       hw.system_config,
       hw.machine_architecture,
       hw.clock_freq_in_mhz as bus_freq_in_mhz,
       hw.MEMORY_SIZE_IN_MB,
       hw.AVAIL_MEMORY_SIZE_IN_MB,
       hw.LOCAL_DISK_SPACE_IN_GB,
       hw.AVAIL_LOCAL_DISK_SPACE_IN_GB,
       hw.cpu_count,
       hw.SYSTEM_SERIAL_NUMBER,
       ( select min(freq_in_mhz)
         from mgmt_ecm_hw_cpu cpu
         where s.snapshot_guid = cpu.ecm_snapshot_id ) as min_cpu_speed_in_mhz,
       ( select max(freq_in_mhz)
         from mgmt_ecm_hw_cpu cpu
         where s.snapshot_guid = cpu.ecm_snapshot_id ) as max_cpu_speed_in_mhz,
       ( select max(vendor_name || ' ' || impl || ' ' || freq_in_mhz || 'MHz')
         from mgmt_ecm_hw_cpu cpu
         where s.snapshot_guid = cpu.ecm_snapshot_id) as cpu,
       hw.cpu_board_count,
       hw.iocard_count,
       ( select count(*)
         from mgmt_ecm_hw_nic nic
         where s.snapshot_guid = nic.ecm_snapshot_id ) as nic_count,
       hw.fan_count,
       hw.power_supply_count,
       hw.system_bios,
       os.name || ' ' || os.base_version || ' ' || os.update_level || '(' || os.address_length_in_bits || ')'
               || decode (os.distributor_version, 'N/A', '', ' ' || os.distributor_version) as operatingsystem,
       os.name as os_name,
       os.vendor_name as os_vendor_name,
       os.base_version as os_base_version,
       os.update_level as os_update_level,
       os.distributor_version as os_distributor_version,
       os.max_swap_space_in_mb,
       os.address_length_in_bits as os_address_length_in_bits,
       os.max_process_virtual_memory,
       os.TIMEZONE,
       os.TIMEZONE_REGION,
       os.TIMEZONE_DELTA,
       ( select count(*)
         from mgmt_ecm_os_property p
         where s.snapshot_guid = p.ecm_snapshot_id ) as number_of_os_properties,
       ( select count(*)
         from mgmt_ecm_os_component c
         where s.snapshot_guid = c.ecm_snapshot_id and c.type = 'Patch' ) as number_of_os_patches,
       ( select count(*)
         from mgmt_ecm_os_filesystem f
         where s.snapshot_guid = f.ecm_snapshot_id ) as number_of_os_filesystems,
       ( select count(*)
         from mgmt_ecm_os_registered_sw s
         where s.snapshot_guid = s.ecm_snapshot_id ) as number_of_os_registered_sw,
       s.snapshot_guid as snapshot_id,
       s.target_guid as target_id,
       s.target_name as internal_target_name,
       s.target_type as internal_target_type,
       s.elapsed_time as collection_duration,
       s.saved_timestamp as loaded_timestamp,
       info.applet_version,
       info.target_id_method,
       info.custom_class,
       info.custom_class_version,
       NVL(info.target_key1, ' ') as key1,
       NVL(info.target_key2, ' ') as key2,
       NVL(info.target_key3, ' ') as key3,
       info.proxy_target_name,
       info.proxy_target_display_name,
       info.proxy_target_id,
       ( select count(*)
         from mgmt_ecm_csa_rules r
         where s.snapshot_guid = r.ecm_snapshot_id) as rules_count,
       ( select count(*)
         from mgmt_ecm_csa_rules r
         where
           s.snapshot_guid = r.ecm_snapshot_id
           and r.status = -2 ) as rules_na_count,
       ( select count(*)
         from mgmt_ecm_csa_rules r
         where
           s.snapshot_guid = r.ecm_snapshot_id
           and r.status = 15 ) as rules_passed_count,
       ( select count(*)
         from mgmt_ecm_csa_rules r
         where
           s.snapshot_guid = r.ecm_snapshot_id
           and r.status = 18 ) as rules_info_count,
       ( select count(*)
         from mgmt_ecm_csa_rules r
         where
           s.snapshot_guid = r.ecm_snapshot_id
           and r.status = 20 ) as rules_warning_count,
       ( select count(*)
         from mgmt_ecm_csa_rules r
         where
           s.snapshot_guid = r.ecm_snapshot_id
           and r.status = 25 ) as rules_critical_count
  FROM mgmt_ecm_gen_snapshot s, mgmt_ecm_csa csa,
      mgmt_ecm_csa_general_info info, mgmt_ecm_hw hw,
      mgmt_ecm_os os
WHERE s.snapshot_type = 'oracle_csa_host'
  AND s.is_current = 'Y'
  AND s.snapshot_guid = csa.ecm_snapshot_id
  AND s.snapshot_guid = info.ecm_snapshot_id
  AND s.snapshot_guid = hw.ecm_snapshot_id
  AND s.snapshot_guid = os.ecm_snapshot_id
  AND (EXISTS (SELECT * FROM mgmt_ecm_csa_appid_target_map m,
                             mgmt_targets t
               WHERE info.appid = m.appid
                 AND t.target_guid = m.target_guid)
      OR
      mgmt_user.has_priv(mgmt_user.get_current_em_user(), 'SUPER_USER') = 1)
WITH READ ONLY
/

