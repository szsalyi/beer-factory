create view EM$RT_COOKIE_DATA as
  SELECT raw_index,name,value
    FROM
      MGMT_RT_COOKIE_DATA
/

