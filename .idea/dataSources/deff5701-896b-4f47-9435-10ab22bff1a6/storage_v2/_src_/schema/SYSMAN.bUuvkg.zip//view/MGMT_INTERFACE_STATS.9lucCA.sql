create view MGMT$INTERFACE_STATS as
  SELECT tguid,
       hostname,
       targetname,
       ifname,
       totrate,
       toterr,
       inrate,
       collection_timestamp
FROM TABLE ( EMD_RAC.INTERFACE_STATS() )
/

