create view MGMT_PROVISION_ASN_HW_SEARCH2 as
  SELECT
    hw.hw_guid, hw.hostname, hw.new_hostname, hw.purpose, hw.serial_number,
    hw.name, hw.description, tgt.current_asn_guid,
    tgt.component_urn, tgt.network_urn, tgt.status, asntgt.status as prov_status,
    summ.system_config, summ.mem, cpu.freq_in_mhz as freq, summ.cpu_count
FROM
    mgmt_prov_hardware hw, mgmt_prov_tgt_status tgt,
    mgmt_prov_asn_targets asntgt, mgmt$os_hw_summary summ, ecm$cpu_details cpu
WHERE
   tgt.current_asn_guid !=  ' '
AND
    hw.hw_guid = asntgt.prov_tgt_guid
AND
    tgt.prov_tgt_guid = asntgt.prov_tgt_guid
AND
    (tgt.current_asn_guid = asntgt.assignment_guid)
AND
    summ.host_name = hw.hostname
AND
    tgt.prov_target_type = 'hw'
AND
   cpu.ecm_snapshot_id =summ.snapshot_guid
UNION
SELECT
    hw.hw_guid, hw.hostname, hw.new_hostname, hw.purpose, hw.serial_number,
    hw.name, hw.description, tgt.current_asn_guid,
    tgt.component_urn, tgt.network_urn, tgt.status, 'STATE_Provisioned' as prov_status,
    summ.system_config, summ.mem, cpu.freq_in_mhz as freq, summ.cpu_count
FROM
    mgmt_prov_hardware hw, mgmt_prov_tgt_status tgt, mgmt$os_hw_summary summ, ecm$cpu_details cpu
WHERE
    hw.hw_guid = tgt.prov_tgt_guid
AND
    decode(rawtohex(tgt.current_asn_guid), '', 'EMPTY') = 'EMPTY'
AND
    summ.host_name = hw.hostname
AND
    tgt.prov_target_type = 'hw'
AND
   cpu.ecm_snapshot_id =summ.snapshot_guid
WITH READ ONLY
/

