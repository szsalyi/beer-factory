create view MGMT$DB_CONTROLFILES as
  select
  g.host_name,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  c.file_name,
  c.status,
  c.creation_date,
  c.sequence_num,
  c.change_num,
  c.mod_date,
  c.os_storage_entity
from
  mgmt_targets g,
  mgmt_db_controlfiles_ecm c,
  mgmt_ecm_gen_snapshot s
where
  s.snapshot_guid = c.ecm_snapshot_id and
  s.target_guid = g.target_guid and
  s.is_current = 'Y'
/

