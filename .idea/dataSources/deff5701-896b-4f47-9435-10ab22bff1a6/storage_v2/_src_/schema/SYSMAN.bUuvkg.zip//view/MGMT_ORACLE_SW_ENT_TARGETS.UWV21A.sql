create view MGMT$ORACLE_SW_ENT_TARGETS as
  SELECT target.target_type as target_type,
         target.host_name as host_target_name,
         target.target_name as target_name,
         target.target_guid as target_guid,
         location_property.property_value as home_location
  FROM
         mgmt_targets target,
         mgmt_target_properties location_property
  WHERE
        location_property.target_guid = target.target_guid
        and location_property.property_name = 'OracleHome'
        and (exists (select * from mgmt_target_properties sub_type
                 where target.target_guid = sub_type.target_guid
         ) )
/

