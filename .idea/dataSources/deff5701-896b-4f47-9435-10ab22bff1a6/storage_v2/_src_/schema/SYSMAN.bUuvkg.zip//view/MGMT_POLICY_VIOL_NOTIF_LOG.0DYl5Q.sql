create view MGMT$POLICY_VIOL_NOTIF_LOG as
  SELECT
	     t.target_name, t.target_type, t.target_guid,
             p.policy_name, v.policy_guid,p.description,
             v.key_value, null, null, null, null,
             v.message,
             DECODE(v.violation_level, 18, 'Informational',
                                       20, 'Warning',
                                       25, 'Critical', v.violation_level),
             v.collection_timestamp,
             n.message, n.timestamp
           FROM mgmt_notification_log n,
	        mgmt_targets t,
		mgmt_policies p,
		mgmt_violations v
           WHERE n.source_obj_type = 1
             AND v.violation_guid = n.source_obj_guid
             AND v.violation_type = 3
             AND p.policy_guid = v.policy_guid
             AND t.target_guid = v.target_guid
             AND p.target_type = t.target_type
	  UNION ALL
         SELECT
	     t.target_name, t.target_type, t.target_guid,
             p.policy_name, v.policy_guid,p.description,
             k.key_part1_value, k.key_part2_value, k.key_part3_value,
             k.key_part4_value, k.key_part5_value,
	     v.message,
             DECODE(v.violation_level, 18, 'Informational',
                                       20, 'Warning',
                                       25, 'Critical', v.violation_level),
             v.collection_timestamp,
             n.message, n.timestamp
           FROM mgmt_notification_log n,
	        mgmt_targets t,
		mgmt_policies p,
		mgmt_violations v,
		mgmt_metrics_composite_keys k
           WHERE n.source_obj_type = 1
             AND v.violation_guid = n.source_obj_guid
             AND v.violation_type = 3
             AND p.policy_guid = v.policy_guid
             AND t.target_guid = v.target_guid
             AND p.target_type = t.target_type
             AND k.target_guid = v.target_guid
             AND v.key_value = k.composite_key
   WITH READ ONLY
/

