create view ECM$OS_PROPERTIES as
  select
  snapshot_guid as ecm_snapshot_id,
  type,
  name,
  value
from MGMT_HC_OS_PROPERTIES
/

