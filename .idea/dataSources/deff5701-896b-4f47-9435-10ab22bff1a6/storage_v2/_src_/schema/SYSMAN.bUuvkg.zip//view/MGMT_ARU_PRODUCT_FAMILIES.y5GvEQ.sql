create view MGMT_ARU_PRODUCT_FAMILIES as
  select product_id as family_id,
       product_name as family_name
from mgmt_aru_products p
where exists
(
  select *
  from mgmt_aru_family_product_map m
  where p.product_id = m.family_id
)
/

