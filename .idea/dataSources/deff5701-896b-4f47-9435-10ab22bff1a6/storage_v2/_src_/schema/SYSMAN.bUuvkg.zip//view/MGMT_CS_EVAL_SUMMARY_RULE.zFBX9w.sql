create view MGMT$CS_EVAL_SUMMARY_RULE as
  SELECT t.target_name, t.target_type, t.target_guid,
    NVL(rnem.message, r.rule_dname) as rule_name,
    r.rule_dname as rule_name_nlsid,
    r.rule_guid as rule_guid,
    NVL(cnem.message, cs.cs_dname) as cs_name,
    cs.cs_dname as cs_name_nlsid,
    cs.author as cs_author,
    cs.version as cs_version,
    cs.cs_guid as cs_guid,
    e.total_violations as total_violations,
    DECODE(e.status, 0, 'Error',
                     1, 'Compliant',
                     2, 'Non-Compliant',
                     3, 'Unknown'),
    DECODE(r.importance_level, 0, 'Not Scored',
                     1, 'Extremely Low',
                     2, 'Low',
                     3, 'Normal',
                     4, 'High',
                     5, 'Extremely High')
	FROM mgmt_targets t,
		   mgmt_cs_config_standard cs,
       mgmt_cs_rule r,
       mgmt_cs_eval_summ_rule e,
       (select message, message_id from mgmt_messages
       where subsystem = 'CONFIG_STD' and language_code = 'en' and country_code = ' ') rnem,
       (select message, message_id from mgmt_messages
       where subsystem = 'CONFIG_STD' and language_code = 'en' and country_code = ' ') cnem
  WHERE t.target_guid = e.target_guid
    AND r.rule_guid = e.rule_guid
    AND r.rule_dname = rnem.message_id(+)
    AND cs.cs_dname = cnem.message_id(+)
    AND r.cs_guid = cs.cs_guid
WITH READ ONLY
/

