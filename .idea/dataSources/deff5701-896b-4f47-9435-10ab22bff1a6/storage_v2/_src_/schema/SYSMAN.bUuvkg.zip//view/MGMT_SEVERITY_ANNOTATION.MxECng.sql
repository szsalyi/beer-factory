create view MGMT_SEVERITY_ANNOTATION as
  SELECT source_obj_guid, timestamp, annotation_type, user_name, message
    FROM mgmt_annotation
   WHERE source_obj_type = 1
/

