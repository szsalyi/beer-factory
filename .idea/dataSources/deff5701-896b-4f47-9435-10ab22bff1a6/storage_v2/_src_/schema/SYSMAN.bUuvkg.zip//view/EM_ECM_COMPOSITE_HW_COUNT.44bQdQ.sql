create view EM$ECM_COMPOSITE_HW_COUNT as
  select
  composite_target_type,
  composite_target_name,
  system_config,
  machine_architecture,
  count( * ) as num_hosts
from
  ( select unique
      ct.target_type composite_target_type,
      ct.target_name composite_target_name,
      snapshot_guid
    from
      mgmt_target_assocs composite,
      mgmt_targets ct,
      mgmt_target_assoc_defs def,
      mgmt_targets target,
      mgmt_targets host,
      mgmt_ecm_snapshot ss
    where composite.assoc_target_guid = target.target_guid
      and target.host_name = host.target_name
      and host.target_type = 'host'
      and host.target_name = ss.target_name
      and host.target_type = ss.target_type
      and ss.snapshot_type = 'host_configuration'
      and ss.is_current = 'Y'
      and ct.target_guid = composite.source_target_guid
      and def.assoc_guid = composite.assoc_guid
      and def.assoc_def_name = 'contains'
      and def.scope_target_type = ' '
  ) ss,
  mgmt_hc_hardware_master hw
where ss.snapshot_guid = hw.snapshot_guid
group by composite_target_type, composite_target_name, system_config, machine_architecture
WITH READ ONLY
/

