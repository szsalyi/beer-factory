create view MGMT$SOFTWARE_COMPONENTS as
  SELECT
  comp.name as name,
  comp.external_name,
  comp.version as base_version,
  home.patchsets patchsets_in_home,
  decode(patch.version, NULL, comp.version, patch.version) as version,
  home.host_name,
  home.container_location as home_location,
  home.container_name as home_name,
  comp.description,
  comp.installer_version, comp.min_deinstaller_version,
  comp.timestamp as install_timestamp,
  comp.is_top_level,
  home.interim_patches interim_patches_in_home,
  home.bugs_fixed_by_interim_patches,
  home.snapshot_guid
FROM
  (SELECT s.target_name host_name, c.container_guid,
          c.container_location, c.container_name,
          ecm_util.patchsets_in_home(c.container_guid) patchsets,
          ecm_util.interim_patches_in_home(c.container_guid) interim_patches,
          ecm_util.fixed_bugs_in_home(c.container_guid) bugs_fixed_by_interim_patches,
          s.snapshot_guid
    FROM mgmt_inv_container c, mgmt_ecm_snapshot s, mgmt_targets t
    WHERE c.snapshot_guid = s.snapshot_guid
     AND s.is_current = 'Y'
     AND s.snapshot_type = 'host_configuration'
     AND t.target_name = s.target_name
     AND t.target_type = 'host'
  ) home,
  mgmt_inv_component comp,
  mgmt_inv_versioned_patch patch
WHERE home.container_guid = comp.container_guid
  AND comp.component_guid = patch.component_guid(+)
WITH READ ONLY
/

