create view MGMT$CSM_REGION_DAILY as
  SELECT
  st.target_name, st.target_type,
  rg.region_name, ru.rollup_timestamp, ru.metric_name,
  SUM(ru.hits),
  DECODE(SUM(ru.hits),
    0, 0,
    SUM(ru.response_time_average * ru.hits)/SUM(ru.hits)),
  MIN(ru.response_time_minimum),
  MAX(ru.response_time_maximum),
  DECODE(
    SUM(ru.hits),
    0, 0,
    1, 0,
    SQRT(
      (SUM(ru.hits) *
        (SUM(DECODE(ru.hits,
          0, 0,
          (((ru.response_time_variance * ru.hits * (ru.hits - 1)) +
            POWER((ru.hits * ru.response_time_average), 2)) / ru.hits))
        )) - POWER(SUM(ru.response_time_average * ru.hits), 2)
      ) / (SUM(ru.hits) * (SUM(ru.hits) - 1))
    )
  ),
  DECODE(
    SUM(ru.hits),
    0, 0,
    1, 0,
    (SUM(ru.hits) *
      (SUM(DECODE(ru.hits,
        0, 0,
        (((ru.response_time_variance * ru.hits * (ru.hits - 1)) +
          POWER((ru.hits * ru.response_time_average), 2)) / ru.hits))
      )) - POWER(SUM(ru.response_time_average * ru.hits), 2)
    ) / (SUM(ru.hits) * (SUM(ru.hits) - 1))
  )
FROM
  MGMT_RT_DOMAIN_1DAY ru,
  MGMT_TARGET_ASSOCS tm,
  MGMT_RT_REGIONS rg,
  MGMT_TARGETS st,
  MGMT_TARGET_ASSOC_DEFS d
WHERE
  ru.target_guid = tm.assoc_target_guid
  AND tm.source_target_guid = rg.target_guid
  AND tm.assoc_guid = d.assoc_guid
  AND d.assoc_def_name = 'supports_eum_on'
  AND d.scope_target_type = ' '
  AND st.target_guid = tm.source_target_guid
  AND rg.region_guid IN (
   SELECT mp.region_guid /*+ INDEX(mgmt_rt_region_entries IDX_REGION_MIN_IP) */
     FROM mgmt_rt_region_entries e, mgmt_rt_region_mapping mp
     WHERE e.id = mp.id
       AND ((e.min_ip >= 0 AND
             ru.visitor_subnet_num BETWEEN e.min_ip AND e.max_ip)
         OR (e.min_ip < 0 AND UPPER(substr('.'||ru.visitor_domain,
             -LENGTH(e.domain)-1)) = UPPER('.'||e.domain))))
GROUP BY
  st.target_name, st.target_type,
  rg.region_name, ru.rollup_timestamp, ru.metric_name
WITH READ ONLY
/

