create view MGMT$HW_NIC as
  select
  s.target_name as host_name,
  n.name as name,
  n.inet_address as inet_address,
  n.max_transfer_unit as max_transfer_unit,
  n.broadcast_address as broadcast_address,
  n.mask as mask,
  n.flags as flags,
  n.mac_address as mac_address,
  n.hostname_aliases as host_aliases,
  s.snapshot_guid
from
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_nic_details n
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = n.snapshot_guid
/

