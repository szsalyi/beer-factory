create view MGMT_V_HOST_DISK_LIST as
  SELECT target_name,
         target_type,
         ecm_snapshot_id,
         global_unique_id,
         resource_name,
         resource_type,
         file_type AS device_type,
         disk_vendor AS vendor,
         storage_size,
         allocated,
         unallocated,
         count(DISTINCT target_name)
           OVER( PARTITION BY target_type, global_unique_id )
           AS shared_count
  FROM
  (
    SELECT data.global_unique_id,
           nvl(data.disk_used_path, name) as resource_name,
           data.entity_type AS resource_type,
           file_type,
           data.disk_vendor,
           nvl(data.sizeb,0) AS storage_size,
           nvl(data.usedb,0) AS allocated,
           nvl(data.freeb,0) AS unallocated,
           data.target_name, data.target_type,
           data.ecm_snapshot_id as ecm_snapshot_id
    FROM mgmt_v_storage_report_data data,
         mgmt$ecm_current_snapshots snap
    WHERE snap.ecm_snapshot_id = data.ecm_snapshot_id
      AND data.storage_layer = 'OS_DISK'
  )
/

