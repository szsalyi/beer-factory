create view EM$RT_DOMAIN_SLOWEST_UNF_1DAY as
  SELECT m.source_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        METRIC_NAME,
        VISITOR_DOMAIN,
        sum(response_time_average*hits)/sum(hits), min(response_time_minimum),
        max(response_time_maximum), sum(RESPONSE_TIME_SDEV*hits)/sum(hits),
        sum(hits)
    FROM MGMT_RT_DOMAIN_1HOUR d, MGMT_TARGET_ASSOCS m,
         MGMT_TARGETS ct, MGMT_TARGET_ASSOC_DEFS def
    WHERE
     d.target_guid = m.assoc_target_guid
     AND def.assoc_guid = m.assoc_guid
     AND def.assoc_def_name = 'supports_eum_on'
     AND def.scope_target_type = ' '
     AND ct.target_guid  = m.source_target_guid
    GROUP BY m.source_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        METRIC_NAME,
        VISITOR_DOMAIN
    ORDER BY sum(response_time_average*hits)/sum(hits) DESC
/

