create view MGMT_CURRENT_SEVERITY as
  SELECT target_guid, policy_guid, key_value, collection_timestamp,
         violation_level, violation_type, violation_guid,
	 annotated_flag, message, message_nlsid, message_params,
	 action_message, action_message_nlsid, action_message_params, advisory_id,
	 load_timestamp
    FROM mgmt_current_violation
   WHERE violation_type IN (0, 1, 2)
/

