create view MGMT$HA_FILES_ALL as
  select
  g.host_name,
  s.ecm_snapshot_id as snapshot_guid,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  s.is_current,
  f.name,
  f.totalsize
from
  mgmt_targets g,
  mgmt_ha_files_ecm f,
  mgmt$ecm_visible_snapshots s
where
  s.ecm_snapshot_id = f.ecm_snapshot_id and
  s.target_guid = g.target_guid (+)
/

