create view MGMT_SEVERITY as
  SELECT target_guid, policy_guid, key_value, collection_timestamp,
         violation_level, violation_type, violation_duration, violation_guid,
	 annotated_flag, notification_status,
	 message, message_nlsid, message_params,
	 action_message, action_message_nlsid, action_message_params, advisory_id,
	 load_timestamp, user_name
    FROM mgmt_violations
   WHERE violation_type IN (0, 1, 2)
/

