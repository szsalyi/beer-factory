create view MGMT$DELTA_ONEOFF_PATCHES as
  select
    e.delta_time as delta_time,
    e.operation as operation,
    s.new_left_target_name as host_name,
    k2.value as home_name,
    k3.value as patch_id,
    decode(v.value, null, v.old_value, v.value) as patch_timestamp
from
  mgmt_delta_ids i,
  mgmt_delta_id_values k2,
  mgmt_delta_id_values k3,
  mgmt_delta_entry e,
  mgmt_delta_entry_values v,
  mgmt_delta_snap s,
  mgmt_targets t
where
  i.collection_type = 'ECM$HIST_INV_PATCHES' and
  i.row_guid = k2.delta_ids_guid and
  k2.name = 'CONTAINER_LOCATION' and
  i.row_guid = k3.delta_ids_guid and
  k3.name = 'ID' and
  i.row_guid = e.row_guid and
  v.delta_entry_guid(+) = e.delta_entry_guid and
  v.name(+) = 'TIMESTAMP' and
  t.target_name = s.new_left_target_name and
  t.target_type = 'host' and
  e.delta_guid = s.delta_guid and
  s.target_type = 'host' and
  s.snapshot_type = 'host_configuration'
/

