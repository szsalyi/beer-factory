create view EM$RT_MEMBER_TARGET_URLS as
  SELECT  m.source_target_guid,ct.TARGET_NAME, ct.TARGET_TYPE,
	  m.assoc_target_guid, u.display_name,
          u.url_filename, u.description
    FROM MGMT_RT_URLS u, mgmt_target_assocs m,
         mgmt_target_assoc_defs d, mgmt_targets ct
   WHERE u.target_guid = m.source_target_guid
     AND d.assoc_guid = m.assoc_guid
     AND d.assoc_def_name = 'supports_eum_on'
     AND scope_target_type = ' '
     AND ct.target_guid = m.source_target_guid
/

