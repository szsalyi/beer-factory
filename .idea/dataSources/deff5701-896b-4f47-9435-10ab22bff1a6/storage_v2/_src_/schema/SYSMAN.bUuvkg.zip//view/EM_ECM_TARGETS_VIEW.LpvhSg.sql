create view EM$ECM_TARGETS_VIEW as
  select db.target_name as target_name,
       db.target_type as target_type,
       db.target_guid as target_guid,
       hos.property_value as platform,
       iv.property_value as version,
       htg.target_name as host,
       dbp.property_value as oracle_home,
       replace(os.address_length_in_bits, '-bit','') as address_size
from mgmt_targets db,
     mgmt_targets htg,
     mgmt_target_properties hos,
     mgmt_target_properties iv,
     mgmt_target_properties dbp,
     mgmt_ecm_snapshot snap,
     mgmt_hc_os_summary os
where
  htg.target_type =  'host' and
  db.host_name = htg.target_name and
  hos.target_guid = htg.target_guid and
  hos.property_name = 'OS' and
  db.target_guid = iv.target_guid and
  iv.property_name = 'Version' and
  dbp.target_guid = db.target_guid and
  dbp.property_name = 'OracleHome' and
  snap.target_name = htg.target_name and
  snap.target_type = htg.target_type and
  snap.snapshot_type = 'host_configuration' and
  snap.is_current = 'Y' and
  os.snapshot_guid = snap.snapshot_guid
WITH READ ONLY
/

