create view MGMT$SOFTWARE_COMP_PATCHSET as
  SELECT
  s.target_name as HOST_NAME,
  h.container_name as HOME_NAME,
  h.container_location as home_location,
  c.name as component_name,
  c.version as component_base_version,
  p.version as component_version,
  ps.name as patchset_name,
  ps.version as patchset_version,
  s.snapshot_guid
FROM
  mgmt_ecm_snapshot s,
  mgmt_inv_container h,
  mgmt_inv_versioned_patch p,
  mgmt_inv_patchset ps,
  mgmt_inv_component c,
  mgmt_targets t
WHERE s.is_current = 'Y'
  AND s.snapshot_type = 'host_configuration'
  AND s.snapshot_guid = h.snapshot_guid
  AND h.container_guid = c.container_guid
  AND p.component_guid = c.component_guid
  AND p.patchset_guid = ps.patchset_guid
  AND t.target_name = s.target_name
  AND t.target_type = 'host'
/

