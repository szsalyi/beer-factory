create view MGMT$PATCH_ADVISORIES as
  SELECT
  hom.advisory_name,
  adv.impact,
  adv.abstract,
  hom.host_name,
  hom.home_location,
  tgt.TARGET_GUID
FROM
  mgmt_bug_advisory adv,
  mgmt_bug_adv_home_patch hom,
  mgmt_targets tgt
WHERE
  adv.advisory_name = hom.advisory_name and
  tgt.target_type = 'host' and
  tgt.target_name = hom.host_name
group by 	hom.advisory_name,impact,abstract,hom.host_name,home_location,tgt.target_guid
WITH READ ONLY
/

