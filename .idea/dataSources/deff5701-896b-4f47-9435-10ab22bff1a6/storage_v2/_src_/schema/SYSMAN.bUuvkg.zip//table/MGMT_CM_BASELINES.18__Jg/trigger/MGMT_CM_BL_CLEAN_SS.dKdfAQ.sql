create trigger MGMT_CM_BL_CLEAN_SS
  after delete
  on MGMT_CM_BASELINES
  for each row
  BEGIN
    DELETE FROM mgmt_CM_SCOPESPECS
           WHERE ss_guid = :old.baseline_ss;
  END;
/

