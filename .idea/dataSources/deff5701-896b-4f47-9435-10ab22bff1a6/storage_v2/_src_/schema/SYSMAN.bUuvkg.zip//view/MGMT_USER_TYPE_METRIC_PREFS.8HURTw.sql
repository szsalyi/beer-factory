create view MGMT_USER_TYPE_METRIC_PREFS as
  SELECT user_name, subtab_name, column_id_guid, 1 + display_order -
           MIN(display_order) OVER (PARTITION BY subtab_name, user_name) AS
           "display_order"
      FROM MGMT_USER_SUBTAB_COL_PREFS
     WHERE column_type = 0
/

