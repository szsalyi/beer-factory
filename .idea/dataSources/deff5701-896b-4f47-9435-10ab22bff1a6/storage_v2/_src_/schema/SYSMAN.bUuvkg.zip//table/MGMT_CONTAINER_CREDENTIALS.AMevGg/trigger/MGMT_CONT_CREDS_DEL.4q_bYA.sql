create trigger MGMT_CONT_CREDS_DEL
  after delete
  on MGMT_CONTAINER_CREDENTIALS
  for each row
  DECLARE
l_target_type MGMT_TARGETS.target_type%TYPE;
BEGIN
    BEGIN
        SELECT  target_type
        INTO    l_target_type
        FROM    MGMT_TARGETS
        WHERE   target_guid=:old.target_guid;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            -- Could happen when target is being deleted?
            NULL;
    END;

    DELETE FROM MGMT_CREDENTIALS2 WHERE credential_guid=:old.credential_guid;

    IF l_target_type IS NULL THEN RETURN; END IF;

    IF NOT MGMT_CREDENTIAL.is_40_style_set(:old.credential_set_name) THEN
        MGMT_JOB_ENGINE.container_creds_deleted(:old.target_guid,
                                                :old.container_location,
                                                :old.credential_set_name,
                                                l_target_type,
                                                :old.user_name);
         MGMT_JOB_ENGINE.suspend_cred_execs;
    END IF;
END;
/

