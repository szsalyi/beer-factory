create view MGMT$JOB_EXECUTION_HISTORY as
  SELECT
        j.job_name, j.job_owner, j.job_id, j.job_type,
        e.execution_id, e.scheduled_time, e.start_time, e.end_time,
        DECODE(status,
                1, 'Scheduled',
                2, 'Running',
                3, 'Failed Initialization',
                4, 'Failed',
                5, 'Succeeded',
                6, 'Suspended By User',
                7, 'Suspended: Agent Unreacheable',
                8, 'Stopped',
                9, 'Suspended on Lock',
               10, 'Suspended on Event',
               11, 'Stop Pending',
               13, 'Suspend Pending',
               14, 'Inactive',
               15, 'Queued',
               16, 'Failed Retried',
               18, 'Skipped', status),
        t.target_name, t.target_type, t.target_guid
      FROM
        MGMT_JOB j,
        MGMT_JOB_EXEC_SUMMARY e,
        MGMT_JOB_TARGET jt,
        MGMT_TARGETS t
      WHERE
        j.job_id=e.job_id AND
        j.is_corrective_action=0 AND
        e.job_id=jt.job_id (+) AND
        e.execution_id=jt.execution_id (+) AND
        jt.target_guid=t.target_guid (+)
      WITH READ ONLY
/

