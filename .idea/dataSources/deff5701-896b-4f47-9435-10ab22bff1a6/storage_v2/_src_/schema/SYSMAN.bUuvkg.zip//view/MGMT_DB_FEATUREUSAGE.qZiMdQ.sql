create view MGMT$DB_FEATUREUSAGE as
  select
  h.host_name as host,
  h.target_name as database_name,
  i.instance_name as instance_name,
  h.target_type   as target_type,
  f.DBID,
  f.NAME,
  f.CURRENTLY_USED,
  f.DETECTED_USAGES,
  f.FIRST_USAGE_DATE,
  f.LAST_USAGE_DATE,
  f.VERSION,
  f.LAST_SAMPLE_DATE,
  f.LAST_SAMPLE_PERIOD,
  f.TOTAL_SAMPLES,
  f.AUX_COUNT,
  f.DESCRIPTION
from
  mgmt_db_featureusage f,
  mgmt_targets h,
  mgmt_db_dbninstanceinfo_ecm i,
  mgmt_ecm_gen_snapshot s
where
  s.is_current = 'Y' and
  s.snapshot_guid = i.ecm_snapshot_id and
  s.target_guid = h.target_guid and
  s.target_guid = f.target_guid
/

