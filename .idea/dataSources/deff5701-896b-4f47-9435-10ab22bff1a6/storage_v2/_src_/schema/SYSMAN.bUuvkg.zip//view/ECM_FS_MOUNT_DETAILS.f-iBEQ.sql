create view ECM$FS_MOUNT_DETAILS as
  select
  snapshot_guid as ecm_snapshot_id,
  resource_name,
  type,
  mount_location,
  mount_options
from MGMT_HC_FS_MOUNT_DETAILS
/

