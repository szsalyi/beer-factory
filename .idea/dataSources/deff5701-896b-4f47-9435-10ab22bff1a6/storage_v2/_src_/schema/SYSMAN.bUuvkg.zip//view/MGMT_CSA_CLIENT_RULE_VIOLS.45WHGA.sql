create view MGMT$CSA_CLIENT_RULE_VIOLS as
  SELECT
  c.appid as application,
  c.compliance as compliance,
  c.csaclient as csaclient,
  c.snapshot_id as snapshotid,
  ecm_util.concat_col('r.name', 'mgmt$csa_host_rules r', 'r.snapshot_id = ''' || c.snapshot_id || ''' and r.status > 15', ',', 50) as list
FROM MGMT$CSA_COLLECTIONS c
/

