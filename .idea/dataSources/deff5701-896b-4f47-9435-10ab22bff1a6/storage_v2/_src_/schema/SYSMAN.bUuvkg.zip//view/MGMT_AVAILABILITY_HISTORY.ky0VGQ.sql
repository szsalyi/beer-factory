create view MGMT$AVAILABILITY_HISTORY as
  SELECT
            t.target_name, t.target_type, t.target_guid,
			v.start_collection_timestamp, v.end_collection_timestamp,
            DECODE (v.current_status, 0, 'Target Down', 1, 'Target Up',
                                      2, 'Metric Error',
                                      3, 'Agent Down', 4, 'Unreachable',
                                      5, 'Blackout', 6, 'Pending/Unknown'),
            v.severity_guid
          FROM
            mgmt_targets t,
            mgmt_availability v
          WHERE t.target_guid = v.target_guid
    WITH READ ONLY
/

