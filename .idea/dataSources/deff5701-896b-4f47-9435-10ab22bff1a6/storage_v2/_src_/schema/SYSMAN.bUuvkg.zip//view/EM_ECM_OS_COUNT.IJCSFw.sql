create view EM$ECM_OS_COUNT as
  SELECT
  o.name,
  o.base_version,
  o.update_level,
  count(*) num_hosts,
  decode(max(o.patches), 0, 'No', 'Yes') as patched
FROM
  mgmt_hc_os_summary o
WHERE
  o.snapshot_guid in
    (
      SELECT /*+ ORDERED */ c.snapshot_guid
      FROM
        mgmt_targets t,
        mgmt_ecm_snapshot s,
        mgmt_ecm_snap_component_info c
      WHERE
        s.snapshot_type     = 'host_configuration'
        AND  s.target_type       = 'host'
        AND  s.target_type       = t.target_type
        AND  s.target_name       = t.target_name
        AND  s.is_current        = 'Y'
        AND  s.snapshot_guid     = c.snapshot_guid
        AND  c.component_name    = 'oracle.os_software'
        AND  c.collection_status = 'COLLECTED'
    )
GROUP BY o.name, o.base_version, o.update_level
WITH READ ONLY
/

