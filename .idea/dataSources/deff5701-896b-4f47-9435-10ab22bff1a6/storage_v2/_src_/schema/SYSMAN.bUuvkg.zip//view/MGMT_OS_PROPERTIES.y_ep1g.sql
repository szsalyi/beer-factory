create view MGMT$OS_PROPERTIES as
  select
  t.target_name as host,
  p.type as source,
  p.name as name,
  p.value as value,
  ecm_util.GET_GENERIC_VALS_DATATYPE( p.value ) as datatype,
  s.snapshot_guid
from
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_os_properties p
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = p.snapshot_guid
/

