create view MGMT$GROUP_MEMBERS as
  SELECT
  m.member_target_name as target_name,
  m.member_target_type as target_type,
  m.member_target_guid as target_guid,
  m.composite_target_name as group_name,
  m.composite_target_type as group_type
FROM
  mgmt$group_flat_memberships m
/

