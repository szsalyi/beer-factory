create view MGMT$APPLIED_PATCHES as
  SELECT
  to_char(patch.id) as patch,
  ecm_util.concat_col('distinct BUG_NUMBER',
  'mgmt_inv_patch_fixed_bug',
  'PATCH_GUID = ''' || patch.patch_guid || '''',',') as bugs,
  patch.timestamp as installation_time,
  tgt.target_name as host,
  con.container_location as home_location,
  con.container_name as home_name,
  con.container_guid,
  tgt.target_guid
FROM
  mgmt_inv_container con,
  mgmt_ecm_snapshot snap,
  mgmt_inv_patch patch,
  mgmt_targets tgt
WHERE
  con.snapshot_guid = snap.snapshot_guid   AND
  snap.is_current = 'Y'   AND
  snap.snapshot_type = 'host_configuration'    AND
  con.container_guid = patch.container_guid   AND
  tgt.target_name = snap.target_name
WITH READ ONLY
/

