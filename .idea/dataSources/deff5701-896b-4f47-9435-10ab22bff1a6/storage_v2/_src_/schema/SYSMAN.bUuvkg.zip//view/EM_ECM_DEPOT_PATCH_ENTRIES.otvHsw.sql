create view EM$ECM_DEPOT_PATCH_ENTRIES as
  SELECT
  pc.BUG_NO AS name,
  pc.TYPE AS type,
  pc.MANUALLY_POSTED AS manually_entered,
  plat_map.em_os_name AS platform,
  pc.ABSTRACT AS description,
  prod_map.em_target_type AS component,
  pc.RELEASE AS component_version,
  pc.language_id AS language,
  pc.ARU_ID AS aru_id,
  pc.platform_id AS platform_id,
  pc.product_id AS product_id,
  pc.PATCH_DATE AS patch_date,
  DECODE(pc.automated,'C','AUTOMATED','M','MANUAL','P','PARTIAL','MANUAL') AS automated
FROM
  MGMT_ECM_PATCH_CACHE pc,
  MGMT_ARU_PRODUCTS prod_map,
  MGMT_ARU_PLATFORMS plat_map
WHERE
  pc.platform_id = plat_map.platform_id(+) AND
  pc.product_id = prod_map.product_id(+)
WITH READ ONLY
/

