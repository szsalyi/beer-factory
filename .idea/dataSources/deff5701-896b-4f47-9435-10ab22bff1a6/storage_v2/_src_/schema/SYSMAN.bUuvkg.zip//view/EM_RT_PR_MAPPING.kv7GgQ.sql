create view EM$RT_PR_MAPPING as
  SELECT
      i.target_guid, page_url, request_url,
      num_cache_hits, cache_hits_avg_svr_time,
      num_non_cache_hits, non_cache_hits_avg_svr_time, i.rollup_timestamp
    FROM
      MGMT_RT_PR_MAPPING_1HOUR i, MGMT_TARGET_ROLLUP_TIMES r
    WHERE i.target_guid = r.target_guid
      AND r.rollup_table_name = 'MGMT_RT_PR_MAPPING_1HOUR'
      AND i.rollup_timestamp <= r.rollup_timestamp
    UNION
    SELECT
      i.target_guid, page_url, request_url,
      num_cache_hits, cache_hits_avg_svr_time,
      num_non_cache_hits, non_cache_hits_avg_svr_time,
      i.aggregate_hour_timestamp
    FROM
      MGMT_RT_PR_MAPPING i, MGMT_TARGET_ROLLUP_TIMES r
    WHERE i.target_guid = r.target_guid
      AND r.rollup_table_name = 'MGMT_RT_PR_MAPPING_1HOUR'
      AND TRUNC(i.aggregate_hour_timestamp, 'HH24') > r.rollup_timestamp
/

