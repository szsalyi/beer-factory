create view ECM$HIST_CPU_DETAILS as
  SELECT
  snapshot_guid AS ecm_snapshot_id,
  vendor_name,
  freq_in_mhz,
  ecache_in_mb,
  impl,
  revision,
  mask,
  count(*) AS count
FROM
  mgmt_hc_cpu_details
GROUP BY snapshot_guid,vendor_name,freq_in_mhz,ecache_in_mb,impl,revision,mask
WITH READ ONLY
/

