create view MGMT$POLICY_VIOLATION_HISTORY as
  SELECT t.target_name, t.target_type, t.type_display_name,
          t.target_guid, p.policy_name,
            p.policy_guid, cm.category_name,
            nvl(k.key_part1_value,v.key_value),
            k.key_part2_value, k.key_part3_value, k.key_part4_value,
            k.key_part5_value, v.collection_timestamp, v.violation_level,
            v.violation_duration, v.message,
            v.message_nlsid, v.message_params
       FROM mgmt_violations v,
            mgmt_targets t,
            mgmt_policies p,
            mgmt_category_map cm,
            mgmt_metrics_composite_keys k
      WHERE v.target_guid = t.target_guid
        AND v.policy_guid = p.policy_guid
        AND v.policy_guid = cm.object_guid (+)
        AND v.key_value = k.composite_key (+)
        AND v.target_guid = k.target_guid (+)
        AND p.policy_type = 2
        AND v.violation_type = 3
        AND cm.class_name (+) = 'Functional'
        AND cm.object_type (+) = 2
 WITH READ ONLY
/

