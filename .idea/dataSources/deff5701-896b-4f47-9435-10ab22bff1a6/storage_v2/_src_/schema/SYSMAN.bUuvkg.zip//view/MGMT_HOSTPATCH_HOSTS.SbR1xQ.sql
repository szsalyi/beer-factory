create view MGMT$HOSTPATCH_HOSTS as
  SELECT t1.target_name as host_name,
       t2.target_name as group_name,
       h.out_of_date_pkgs as out_of_date_packages,
       h.rogue_pkgs as rogue_packages
FROM   mgmt_ecm_hostpatch_hosts h,
       mgmt_targets t1,
       mgmt_targets t2
WHERE  t1.target_guid = h.host_guid
  AND  t2.target_guid = h.group_guid
/

