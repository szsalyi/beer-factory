create view MGMT_COLLECTION_PROPERTIES as
  SELECT object_guid, metric_guid, coll_name,
         property_name, property_value
    FROM mgmt_coll_item_properties
   WHERE object_type = 2
/

