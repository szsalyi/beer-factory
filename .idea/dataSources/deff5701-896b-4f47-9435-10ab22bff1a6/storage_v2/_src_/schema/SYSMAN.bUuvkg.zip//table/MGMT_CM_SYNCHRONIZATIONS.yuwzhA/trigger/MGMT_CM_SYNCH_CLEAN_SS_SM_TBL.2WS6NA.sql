create trigger MGMT_CM_SYNCH_CLEAN_SS_SM_TBL
  after delete
  on MGMT_CM_SYNCHRONIZATIONS
  for each row
  BEGIN
    DELETE FROM MGMT_CM_SCOPESPECS
           WHERE ss_guid = :old.synch_ss;
    DELETE FROM MGMT_CM_SCHEMA_MAPS
           WHERE owner_id = :old.synch_ss;
    DELETE FROM MGMT_CM_BASELINES
           WHERE BASELINE_GUID = :old.TARGET_TEMP_BL_ID
             AND TEMP_BL = 2;
    IF :old.SOURCE_TEMP_BL_ID IS NOT NULL THEN
      DELETE FROM MGMT_CM_BASELINES
           WHERE BASELINE_GUID = :old.SOURCE_TEMP_BL_ID
             AND TEMP_BL = 2;
    END IF;
  end;
/

