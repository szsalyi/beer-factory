create view MGMT$DELTA_COMPONENTS as
  select
    e.delta_time as delta_time,
    e.operation as operation,
    s.new_left_target_name as host_name,
    k2.value as home_path,
    k3.value as component_name,
    k4.value as base_version,
    MGMT_DELTA.GET_DELTA_VALUE_DISPLAY_STRING( e.delta_entry_guid, e.operation ) as delta_values
from
  mgmt_delta_ids i,
  mgmt_delta_id_values k2,
  mgmt_delta_id_values k3,
  mgmt_delta_id_values k4,
  mgmt_delta_entry e,
  mgmt_delta_snap s,
  mgmt_targets t
where
  i.collection_type = 'ECM$HIST_INV_COMPONENTS' and
  i.row_guid = k2.delta_ids_guid and
  k2.name = 'CONTAINER_LOCATION' and
  i.row_guid = k3.delta_ids_guid and
  k3.name = 'NAME' and
  i.row_guid = k4.delta_ids_guid and
  k4.name = 'VERSION' and
  i.row_guid = e.row_guid and
  t.target_name = s.new_left_target_name and
  t.target_type = 'host' and
  e.delta_guid = s.delta_guid and
  s.target_type = 'host' and
  s.snapshot_type = 'host_configuration'
/

