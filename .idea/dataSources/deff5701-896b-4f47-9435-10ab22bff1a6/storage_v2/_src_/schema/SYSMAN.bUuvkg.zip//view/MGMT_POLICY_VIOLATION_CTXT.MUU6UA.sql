create view MGMT$POLICY_VIOLATION_CTXT as
  SELECT p.target_type, m.metric_name, p.policy_name, p.policy_guid,
           pv.column_name, pv.is_hidden,
           DECODE(pv.url_link_type,
	            0, 'JSP',
		    1, 'UIX',
		    'UNKNOWN'),
           pv.url_link_template
      FROM mgmt_policies p,
           mgmt_policy_viol_ctxt_def pv,
           (SELECT distinct metric_guid, metric_name
              FROM mgmt_metrics) m
     WHERE p.metric_guid = m.metric_guid
       AND p.policy_guid = pv.policy_guid
       AND p.policy_type = 2
WITH READ ONLY
/

