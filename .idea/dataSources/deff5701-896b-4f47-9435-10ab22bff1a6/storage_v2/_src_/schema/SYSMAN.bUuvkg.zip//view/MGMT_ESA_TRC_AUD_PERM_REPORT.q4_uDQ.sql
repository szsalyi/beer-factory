create view MGMT$ESA_TRC_AUD_PERM_REPORT as
  SELECT  targets.target_guid AS "TARGET_GUID",
        targets.target_name AS "TARGET_NAME",
        collection.value2 as PRINCIPAL,
        decode(property,'audit_file_dest','Audit file destination',
                        'user_dump_dest','User dump destination',
                        'background_dump_dest','Background dump destination',
                        'core_dump_dest','Core dump destination') as OBJECT_NAME,
        collection.value AS permission
FROM esm_collection_latest collection, mgmt_targets targets
WHERE collection.target_guid = targets.target_guid and
      property in ('audit_file_dest',
                   'user_dump_dest',
                   'background_dump_dest',
                   'core_dump_dest')
/

