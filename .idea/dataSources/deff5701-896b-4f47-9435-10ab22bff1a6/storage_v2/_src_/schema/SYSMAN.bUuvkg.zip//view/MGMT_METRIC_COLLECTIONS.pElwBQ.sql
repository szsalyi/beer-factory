create view MGMT_METRIC_COLLECTIONS as
  SELECT c.object_guid, cmt.metric_guid, c.coll_name,
         0, DECODE(c.store_metric, 1, 'Y', 'N'), c.interval,
         c.schedule_ex, cmt.last_collected_timestamp,
	 cmt.status_message, DECODE(c.is_enabled, 1, 0, 1)
    FROM mgmt_collections c,
         mgmt_collection_metric_tasks cmt
   WHERE c.object_guid = cmt.target_guid
     AND c.coll_name = cmt.coll_name
     AND c.object_type = 2
/

