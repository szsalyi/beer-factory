create view MGMT$SOFTWARE_DEPENDENCIES as
  SELECT
  s.target_name as host_name,
  cr.container_name as referencer_home_name,
  cr.container_location as referencer_home_location,
  er.name referencer_name,
  er.version as referencer_base_version,
  cd.container_name as referenced_home_name,
  cd.container_location as referenced_home_location,
  ed.name as referenced_name,
  ed.version as referenced_base_version,
  d.dependency_type,
  s.snapshot_guid
FROM
  mgmt_inv_dependency_rule d,
  mgmt_inv_component er,
  mgmt_inv_component ed,
  mgmt_inv_container cd,
  mgmt_inv_container cr,
  mgmt_ecm_snapshot s,
  mgmt_targets t
WHERE d.dependee_guid = ed.component_guid
  AND ed.container_guid = cd.container_guid
  AND cd.snapshot_guid = s.snapshot_guid
  AND s.is_current = 'Y'
  AND s.snapshot_type = 'host_configuration'
  AND d.referencer_guid = er.component_guid
  AND er.container_guid = cr.container_guid
  AND t.target_name = s.target_name
  AND t.target_type = 'host'
/

