create view MGMT$TARGET_TYPE_DEF as
  SELECT
	      t.target_type, t.type_display_name, t.target_type_guid,
		  t.max_type_meta_ver
		FROM
		    mgmt_target_types t, mgmt_targets tt
		WHERE
		    t.target_type = tt.target_type
	WITH READ ONLY
/

