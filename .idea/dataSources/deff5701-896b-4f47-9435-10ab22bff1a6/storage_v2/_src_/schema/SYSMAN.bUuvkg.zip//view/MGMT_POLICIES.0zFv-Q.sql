create view MGMT$POLICIES as
  SELECT p.target_type, m.metric_name, m.metric_guid,p.policy_name, p.policy_label_nlsid, p.policy_guid,
           p.author, p.description,p.description_nlsid, p.impact,p.impact_nlsid,
           p.recommendation,p.recommendation_nlsid,p.condition_type, p.condition,
           p.condition_operator,
           DECODE(p.violation_level,
                    18, 'Informational',
                    20, 'Warning',
                    25, 'Critical',
                    'Unknown'),
           p.owner, p.auto_enable, func_cats.category_name as category,
           func_cats.category_name_nlsid as category_nlsid
      FROM mgmt_policies p,
           (SELECT catm.target_type, catm.object_guid, c.category_name, c.category_name_nlsid
              FROM mgmt_categories c, mgmt_category_map catm
             WHERE c.class_name = catm.class_name
               AND c.category_name = catm.category_name
               AND c.class_name = 'Functional'
               AND catm.object_type = 2) func_cats,
           (SELECT distinct metric_guid, metric_name
              FROM mgmt_metrics) m
     WHERE p.metric_guid = m.metric_guid
       AND p.policy_type = 2
       AND p.policy_guid = func_cats.object_guid (+)
WITH READ ONLY
/

