create view MGMT$STEPS as
  select txns.name as txn_name,bcn_name, steps.name step_name, txns.target_guid,txns.txn_guid
from mgmt_bcn_txn_defn txns,
     mgmt_bcn_step_defn steps,(select b.target_guid target_guid,mt1.target_name as bcn_name
					from mgmt_bcn_target b,mgmt_targets mt1
					where b.beacon_target_guid = mt1.target_guid
					and mt1.target_type = 'oracle_beacon') bcns
where
steps.txn_guid = txns.txn_guid
and bcns.target_guid = txns.target_guid
and txns.target_guid = steps.target_guid
and txn_type='HTTP'
/

