create trigger EM_UPDATE_COLL_ITEM_PROPERTY
  instead of update
  on MGMT_COLLECTION_PROPERTIES
  for each row
  BEGIN
  -- Update coll_item property
  UPDATE mgmt_coll_item_properties
     SET object_guid = :new.target_guid,
         metric_guid = :new.metric_guid,
	 coll_name   = :new.coll_name,
	 property_name = :new.property_name,
	 property_value = :new.property_value
   WHERE object_guid = :old.target_guid
     AND metric_guid = :old.metric_guid
     AND coll_name = :old.coll_name
     AND property_name = :old.property_name;

END;
/

