create view MGMT_V_ASM_DG_USAGE as
  SELECT t.host_name,
           t.target_name,
           c.key_value disk_group_name,
           max( DECODE( m.metric_column, 'total_mb', c.value, 0))
             as total_mb,
           max( DECODE( m.metric_column, 'usable_file_mb',
             c.value, 0)) as usable_file_mb,
           max(DECODE( p.property_name, 'db_unique_name',
             p.property_value, null)) as db_unique_name,
           max(DECODE( p.property_name, 'cluster_database',
             p.property_value, null)) as cluster_db_flag
    FROM mgmt_current_metrics c,
         mgmt_metrics m,
         mgmt_targets t,
         mgmt_target_properties p,
         mgmt_storage_report_ui_targets uit
    WHERE uit.ecm_snapshot_id IS NOT NULL
      AND t.host_name = uit.target_name
      AND t.target_guid = c.target_guid
      AND t.target_type = 'osm_instance'
      AND m.target_type = t.target_type
      AND c.metric_guid = m.metric_guid
      AND m.metric_name = 'DiskGroup_Usage'
      AND m.metric_column in ('total_mb',
                              'free_mb',
                              'usable_file_mb',
                              'type')
      AND m.type_meta_ver = t.type_meta_ver
      AND (m.category_prop_1 = ' ' OR
           m.category_prop_1 =  t.category_prop_1)
      AND (m.category_prop_2 = ' ' OR
           m.category_prop_2 =  t.category_prop_2)
      AND (m.category_prop_3 = ' ' OR
           m.category_prop_3 =  t.category_prop_3)
      AND (m.category_prop_4 = ' ' OR
           m.category_prop_4 =  t.category_prop_4)
      AND (m.category_prop_5 = ' ' OR
           m.category_prop_5 =  t.category_prop_5)
      AND t.target_guid = p.target_guid
      AND p.property_type = 'INSTANCE'
      AND p.property_name in ( 'db_unique_name', 'cluster_database')
    GROUP BY t.host_name, t.target_name, c.key_value
/

