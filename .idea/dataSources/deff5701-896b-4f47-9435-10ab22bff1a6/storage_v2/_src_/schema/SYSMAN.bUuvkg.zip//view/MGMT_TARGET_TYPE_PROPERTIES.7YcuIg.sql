create view MGMT$TARGET_TYPE_PROPERTIES as
  SELECT
          t.target_name, tp.target_type, tp.property_name, tp.property_value
        FROM
            mgmt_type_properties tp,
			mgmt_targets t
	   WHERE t.target_type=tp.target_type
    WITH READ ONLY
/

