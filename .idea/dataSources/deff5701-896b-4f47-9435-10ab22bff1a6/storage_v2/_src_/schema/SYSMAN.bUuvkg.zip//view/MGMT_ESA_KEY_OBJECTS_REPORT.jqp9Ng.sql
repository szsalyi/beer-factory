create view MGMT$ESA_KEY_OBJECTS_REPORT as
  SELECT  targets.target_guid AS "TARGET_GUID",
        targets.target_name AS "TARGET_NAME",
        collection.value as "user",
        decode(property,'access_aud_table','Table AUD$',
                        'access_user_history','Table USER_HISTORY$',
                        'access_source_table','Table SOURCE$',
                        'access_link_table','Table LINK$',
                        'access_user_table','Table USER$',
                        'access_sql_text','Table STATS$SQLTEXT',
                        'access_sql_summary','Table STATS$SQL_SUMMARY',
                        'access_all_source','View ALL_SOURCE',
                        'access_dba_roles','View DBA_ROLES',
                        'access_dba_sysprivs','View DBA_SYS_PRIVS',
                        'access_dba_roleprivs','View DBA_ROLE_PRIVS',
                        'access_dba_tabprivs','View DBA_TAB_PRIVS',
                        'access_dba_users','View DBA_USERS',
                        'access_role_roleprivs','View ROLE_ROLE_PRIVS',
                        'access_user_tabprivs','View USER_TAB_PRIVS',
                        'access_user_roleprivs','View USER_ROLE_PRIVS') as "object_name",
        collection.value2 as "privilege"
FROM esm_collection_latest collection, mgmt_targets targets
WHERE collection.target_guid = targets.target_guid and
      property in
                        ('access_aud_table',
                        'access_user_history',
                        'access_source_table',
                        'access_link_table',
                        'access_user_table',
                        'access_sql_text',
                        'access_sql_summary',
                        'access_all_source',
                        'access_dba_roles',
                        'access_dba_sysprivs',
                        'access_dba_roleprivs',
                        'access_dba_tabprivs',
                        'access_dba_users',
                        'access_role_roleprivs',
                        'access_user_tabprivs',
                        'access_user_roleprivs')
/

