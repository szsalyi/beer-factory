create trigger MGMT_CM_COMP_CLEAN_ANT
  after delete
  on MGMT_CM_COMPARISON_OBJECTS
  for each row
  BEGIN
        DELETE FROM MGMT_ANNOTATION
         WHERE source_obj_type = mgmt_global.G_ANNOTATION_SOURCE_CM
           AND :old.annotation_guid is not NULL
           AND source_obj_guid = :old.annotation_guid ;
  END;
/

