create trigger BCN_TXN_INSERT_TRIGGER
  before insert
  on MGMT_BCN_TXN_DEFN
  for each row
  DECLARE
  v_txn_guid    RAW(16);
BEGIN

    IF (:new.target_guid IS NOT NULL) AND
       (:new.name IS NOT NULL) THEN

      IF :new.txn_type IS NULL THEN
        :new.txn_type := 'HTTP';
      END IF;

      IF :new.txn_guid IS NULL THEN
        v_txn_guid :=
            dbms_obfuscation_toolkit.md5(
                   input => utl_raw.cast_to_raw(
                                   RAWTOHEX(:new.target_guid) ||
                                   ';' || :new.txn_type ||
                                   ';' || :new.name));
        :new.txn_guid := v_txn_guid;
      END IF;

    END IF;

END;
/

