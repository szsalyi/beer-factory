create view MGMT_LICENSE_VIEW as
  SELECT a.target_name,
    a.target_type,
    b.pack_name,
    decode(c.target_name, a.target_name, null, c.target_name)
    parent_target_name,
    decode(c.target_type, a.target_type, null, c.target_type)
    parent_target_type
FROM mgmt_targets a,
    mgmt_licensed_targets b,
    mgmt_targets c
WHERE
    b.target_guid=a.target_guid AND
    b.from_target_guid=c.target_guid
/

