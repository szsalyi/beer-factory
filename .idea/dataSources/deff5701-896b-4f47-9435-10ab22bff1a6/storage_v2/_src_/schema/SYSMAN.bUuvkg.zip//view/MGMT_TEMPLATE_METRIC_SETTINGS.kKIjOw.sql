create view MGMT$TEMPLATE_METRIC_SETTINGS as
  SELECT tt.template_name, tt.target_type, tt.template_guid,
           m.metric_name, m.metric_column, m.metric_guid,
           pa.coll_name, func_cats.category_name, pac.key_value,
           null, null, null, null, pac.key_operator,
           pac.prevent_override, pac.condition_operator,
           pacp.warn_threshold, pac.condition_operator,
           pacp.crit_threshold, pac.num_occurrences,
           DECODE(TRIM(pac.fixit_job),
                    NULL, DECODE(tgt_warn_cas.job_type,
                                   NULL, 'No-action',
                                   'Corrective-Action'),
                    'Agent-Fixit Job'),
           tgt_warn_cas.job_type, tgt_warn_cas.job_owner, tgt_warn_cas.job_name,
           DECODE(TRIM(pac.fixit_job),
                    NULL, DECODE(tgt_crit_cas.job_type,
                                   NULL, 'No-action',
                                   'Corrective-Action'),
                    'Agent-Fixit Job'),
           tgt_crit_cas.job_type, tgt_crit_cas.job_owner, tgt_crit_cas.job_name
      FROM mgmt_templates tt,
           mgmt_metrics m,
           (SELECT target_type, object_guid, category_name
              FROM mgmt_category_map catm
             WHERE class_name = 'Functional'
               AND object_type = 1) func_cats,
             mgmt_policy_assoc pa,
             mgmt_policy_assoc_cfg pac,
             mgmt_policy_assoc_cfg_params pacp,
             (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                     j.job_owner, j.job_name
                FROM mgmt_job j, mgmt_corrective_action ca
               WHERE j.job_id = ca.job_id
                 AND j.is_corrective_action = 1
                 AND ca.ca_scope = 2) tgt_warn_cas,
             (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                     j.job_owner, j.job_name
                FROM mgmt_job j, mgmt_corrective_action ca
               WHERE j.job_id = ca.job_id
                 AND j.is_corrective_action = 1
                 AND ca.ca_scope = 2) tgt_crit_cas
     WHERE tt.target_type = m.target_type
       AND pa.object_guid = tt.template_guid
       AND pa.policy_guid = m.metric_guid
       AND pa.policy_type = 1
       AND pa.object_type = 3
       AND pa.object_guid = pac.object_guid
       AND pa.policy_guid = pac.policy_guid
       AND pa.coll_name = pac.coll_name
       AND pac.object_guid = pacp.object_guid
       AND pac.policy_guid = pacp.policy_guid
       AND pac.coll_name = pacp.coll_name
       AND pac.key_value = pacp.key_value
       AND pac.key_operator = pacp.key_operator
       AND m.num_keys < 2
       AND pacp.param_name = ' '
       AND func_cats.object_guid (+) = m.metric_guid
       AND tgt_warn_cas.job_id (+) = pac.warn_action_job_id
       AND tgt_warn_cas.ca_template_guid (+) = pac.object_guid
       AND tgt_crit_cas.job_id (+) = pac.crit_action_job_id
       AND tgt_crit_cas.ca_template_guid (+) = pac.object_guid
  UNION ALL
    SELECT tt.template_name, tt.target_type, tt.template_guid,
           m.metric_name, m.metric_column, m.metric_guid,
           pa.coll_name, func_cats.category_name,
		   k.key_part1_value, k.key_part2_value, k.key_part3_value,
		   k.key_part4_value, k.key_part5_value, pac.key_operator,
           pac.prevent_override, pac.condition_operator,
           pacp.warn_threshold, pac.condition_operator,
           pacp.crit_threshold, pac.num_occurrences,
           DECODE(TRIM(pac.fixit_job),
                    NULL, DECODE(tgt_warn_cas.job_type,
                                   NULL, 'No-action',
                                   'Corrective-Action'),
                   'Agent-Fixit Job'),
           tgt_warn_cas.job_type, tgt_warn_cas.job_owner, tgt_warn_cas.job_name,
           DECODE(TRIM(pac.fixit_job),
                    NULL, DECODE(tgt_crit_cas.job_type,
                                   NULL, 'No-action',
                                   'Corrective-Action'),
                    'Agent-Fixit Job'),
           tgt_crit_cas.job_type, tgt_crit_cas.job_owner, tgt_crit_cas.job_name
      FROM mgmt_templates tt,
           mgmt_metrics m,
           mgmt_metrics_composite_keys k,
           (SELECT target_type, object_guid, category_name
              FROM mgmt_category_map catm
             WHERE class_name = 'Functional'
               AND object_type = 1) func_cats,
           mgmt_policy_assoc pa,
           mgmt_policy_assoc_cfg pac,
           mgmt_policy_assoc_cfg_params pacp,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
              FROM mgmt_job j, mgmt_corrective_action ca
             WHERE j.job_id = ca.job_id
               AND j.is_corrective_action = 1
               AND ca.ca_scope = 2) tgt_warn_cas,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
              FROM mgmt_job j, mgmt_corrective_action ca
             WHERE j.job_id = ca.job_id
               AND j.is_corrective_action = 1
               AND ca.ca_scope = 2) tgt_crit_cas
     WHERE tt.target_type = m.target_type
       AND pa.object_guid = tt.template_guid
       AND pa.policy_guid = m.metric_guid
       AND pa.policy_type = 1
       AND pa.object_guid = pac.object_guid
       AND pa.policy_guid = pac.policy_guid
       AND pa.coll_name = pac.coll_name
       AND pac.object_guid = pacp.object_guid
       AND pac.policy_guid = pacp.policy_guid
       AND pac.coll_name = pacp.coll_name
       AND pac.key_value = pacp.key_value
       AND pac.key_operator = pacp.key_operator
       AND pa.object_type = 3
       AND m.num_keys > 1
       AND pacp.param_name = ' '
       AND func_cats.object_guid (+) = m.metric_guid
       AND tgt_warn_cas.job_id (+) = pac.warn_action_job_id
       AND tgt_warn_cas.ca_template_guid (+) = pac.object_guid
       AND tgt_crit_cas.job_id (+) = pac.crit_action_job_id
       AND tgt_crit_cas.ca_template_guid (+) = pac.object_guid
       AND k.target_guid = pac.object_guid
       AND pac.key_value = k.composite_key
WITH READ ONLY
/

