create view MGMT_V_STORAGE_LYR_EXISTENCE as
  SELECT db_exists_flag, asm_exists_flag,
         rac_exists_flag, local_fs_exists_flag,
         writeable_nfs_exists_flag, vol_exists_flag,
         disk_exists_flag
  FROM
  (
    SELECT max( DECODE( tgt.target_type,
                        'oracle_database', 'Y', 'N')) db_exists_flag,
           max( DECODE( tgt.target_type,
                        'osm_instance', 'Y', 'N')) asm_exists_flag,
           max( DECODE( tgt.target_type,
                        'rac_database', 'Y', 'N')) rac_exists_flag
    FROM mgmt_targets tgt,
         mgmt_storage_report_ui_targets uit
    WHERE uit.ecm_snapshot_id IS NOT NULL
      AND uit.target_name = tgt.host_name
      AND tgt.target_type in ( 'osm_instance',
                               'oracle_database',
                               'rac_database' )
  ),
  (
    SELECT max( DECODE( storage_layer,
                        'LOCAL_FILESYSTEM', 'Y', 'N')) local_fs_exists_flag,
           max( DECODE( storage_layer||nfs_mount_privilege,
                        'NFSWRITE', 'Y', 'N')) writeable_nfs_exists_flag,
           max( DECODE( storage_layer,
                        'VOLUME_MANAGER', 'Y', 'N')) vol_exists_flag,
           max( DECODE( storage_layer,
                        'OS_DISK', 'Y', 'N')) disk_exists_flag
    FROM mgmt_v_storage_report_data data,
         mgmt_storage_report_ui_targets uit
    WHERE uit.ecm_snapshot_id = data.ecm_snapshot_id
  )
/

